## 性能

### 垃圾回收
小游戏中，JavaScript 中的每一个 Canvas 或 Image 对象都会有一个客户端层的实际纹理储存，实际纹理储存中存放着 Canvas、Image 的真实纹理，通常会占用相当一部分内存。
每个客户端实际纹理储存的回收时机依赖于 JavaScript 中的 Canvas、Image 对象回收。在 JavaScript 的 Canvas、Image 对象被回收之前，客户端对应的实际纹理储存不会被回收。通过调用 [wx.triggerGC()](../../document/performance/wx.triggerGC.md) 方法，可以加快触发 JavaScriptCore Garbage Collection（垃圾回收），从而触发 JavaScript 中没有引用的 Canvas、Image 回收，释放对应的实际纹理储存。
但 GC 具体触发时机还要取决于 JavaScriptCore 自身机制，并不能保证调用 [wx.triggerGC()](../../document/performance/wx.triggerGC.md) 能马上触发回收，建议在每局游戏开始或结束触发一下。

### 混合渲染模式
在一些混合渲染模式的游戏中，游戏场景使用了 WebGL 的模式渲染，但是一些 GUI 以及 排行榜 等内容会使用 canvas 2d 的模式渲染。

在原有逻辑里，需要使用 gl.texImage2d 接口来渲染。
```
gl.texImage2D(target, level, internalformat, format, type, canvas)
```

每次更新 canvas 之后，都需要重新调用一次接口。

为了解决这里的问题，在 gl context 上引入了新方法 [WebGLRenderingContext.wxBindCanvasTexture()](../../document/render/canvas/WebGLRenderingContext.wxBindCanvasTexture.md)，该方法接受一个 Canvas 作为参数，并把这个 Canvas 对应的 Texture 绑定到 gl 上。

```
gl.wxBindCanvasTexture(gl.TEXTURE_2D, canvas)
```

在此之后，只需要更新 Canvas 即可。

目前该方法仅支持 iOS。