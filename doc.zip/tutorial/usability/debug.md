## 调试

### vConsole

在真机上，如果想要查看 console.log，console.error 等 API 输出的内容，需要在点击屏幕右上角的按钮打开的菜单里点击 `打开调试`。此时小程序会退出，重新打开后会发现右下角有一个 `vConsole` 按钮。点击 `vConsole` 按钮可以打开日志面板。

![](../images/vConsole.jpg)

在真机上 console.log 等 API 无法输出有循环引用的对象。假设按照如下代码，尝试输出有循环引用的对象 a

```javascript
var a = {}
a.b = a
console.log(a)
```

将会产生这样的错误

```
An object width circular reference can't be logged
```