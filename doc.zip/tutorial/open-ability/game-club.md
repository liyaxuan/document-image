## 游戏圈使用指南

开发者可以通过游戏圈组件，在小游戏内为用户提供游戏交流、用户互动、反馈收集等社区能力。

#### 接入方式

开发者可直接调用 [wx.createGameClubButton()](../../document/open-api/game-club/wx.createGameClubButton.md) 创建打开游戏圈的按钮。

同时，根据游戏界面的不同UI风格，我们在组件内提供以下 4 种 icon 样式可供选择：

| 值 | 图标 |
| --- | ---|
| dark | <img src="../images/game-club/dark.png" width="64" height="64"> |
| green | <img src="../images/game-club/green.png" width="64" height="64"> |
| white | <img src="../images/game-club/white.png" width="64" height="64"> （灰色背景仅用作显示图标，图标本身为白色） |
| light | <img src="../images/game-club/light.png" width="64" height="64"> |

#### 运营与管理

除此之外，我们为开发者提供了游戏圈社区能力的运营与管理能力，开发者可以在MP管理后台配置游戏圈管理员。游戏圈管理员可以在手机端操作帖子置顶、沉底、屏蔽等权限，管理和维护健康的游戏圈内容与社区环境。

- MP管理后台游戏圈配置界面

![mp](../images/game-club/mp.jpg)

- 移动端游戏圈管理员操作界面

![mp](../images/game-club/mobile.jpg)