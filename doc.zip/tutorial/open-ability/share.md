## 转发
用户在使用小游戏过程中，可转发消息给其他用户或群聊。

### 转发菜单
点击右上角按钮，会弹出菜单，菜单中的“转发”选项默认不展示。通过 [wx.showShareMenu()](../../document/share/wx.showShareMenu.md) 和 [wx.hideShareMenu()](../../document/share/wx.hideShareMenu.md) 可动态显示、隐藏这个选项。

### 被动转发
用户点击右上角菜单中的“转发”选项后，会触发转发事件，如果小游戏通过 [wx.onShareAppMessage()](../../document/share/wx.onShareAppMessage.md) 监听了这个事件，可通过返回自定义转发参数来修改转发卡片的内容，否则使用默认内容。

```javascript
wx.onShareAppMessage(function () {
  // 用户点击了“转发”按钮
  return {
    title: '转发标题'
  }
})
```

### 主动转发
游戏内可通过 [wx.shareAppMessage()](../../document/share/wx.shareAppMessage.md)接口直接调起转发界面，与被动转发类似，可以自定义转发卡片内容。

```javascript
wx.shareAppMessage({
  title: '转发标题'
})
```

### 使用 Canvas 内容作为转发图片
如果不指定转发图片，默认会显示一个小程序的 logo。如果希望转发的时候显示 Canvas 的内容，可以使用 [Canvas.toTempFilePath()](../../document/render/canvas/Canvas.toTempFilePath.md) 或 [Canvas.toTempFilePathSync()](../../document/render/canvas/Canvas.toTempFilePathSync.md) 来生成一张本地图片，然后把图片路径传给 `imageUrl` 参数。

**转发出来的消息卡片中，图片的最佳显示比例是 5：4**。

```javascript
wx.onShareAppMessage(function () {
  return {
    title: '转发标题',
    imageUrl: canvas.toTempFilePathSync({
      destWidth: 500,
      destHeight: 400
    })
  }
})
```

### withShareTicket 模式
通过 [wx.updateShareMenu](../../document/share/wx.updateShareMenu.md) 接口可修改转发属性。如果设置 `withShareTicket` 为 `true` ，会有以下效果

1. 选择联系人的时候只能选择一个目标，不能多选
2. 消息被转发出去之后，在会话窗口中无法被长按二次转发
3. 消息转发的目标如果是一个群聊，则
  1. 会在转发成功的时候获得一个 `shareTicket`
  2. 每次用户从这个消息卡片进入的时候，也会获得一个 `shareTicket`，通过调用 [wx.getShareInfo()](../../document/share/wx.getShareInfo.md) 接口传入 `shareTicket` 可以获取群相关信息

修改这个属性后，同时对主动转发和被动转发生效。

```javascript
// 设置 withShareTicket: true
wx.updateShareMenu({
  withShareTicket: true
})
```
