## 米大师支付签名

**以查询余额的接口为例**

- 原始请求信息

1) 米大师密钥：zNLgAGgqsEWJOg1nFVaO5r7fAlIQxr1u
2) HTTP请求方式: POST
3) 请求的URI： /cgi-bin/midas/getbalance


- sig签名

1) 参与米大师签名请求参数

```
    "openid":"odkx20ENSNa2w5y3g_qOkOvBNM1g",
    "appid":"wx1234567",
    "offer_id":"12345678",
    "ts":1507530737,
    "zone_id":"1",
    "pf":"android"
```


2) 对参与米大师签名的参数按照key=value的格式，并按照参数名ASCII字典序升序排序如下：

```
stringA="appid=wx1234567&offer_id=12345678&openid=odkx20ENSNa2w5y3g_qOkOvBNM1g&pf=android&ts=1507530737&zone_id=1"
```

3) 拼接uri、method和米大师密钥：

```
stringSignTemp=stringA+"&org_loc=/cgi-bin/midas/getbalance&method=POST&secret=zNLgAGgqsEWJOg1nFVaO5r7fAlIQxr1u"
```

4) 把米大师密钥作为key，使用HMAC-SHA256得到签名。

```
sig=hmac_sha256(key,stringSignTemp)
   ="1ad64e8dcb2ec1dc486b7fdf01f4a15159fc623dc3422470e51cf6870734726b"
```


- mp_sig签名

1) 参与开平签名请求参数
```
    "access_token":"ACCESSTOKEN",
    "openid":"odkx20ENSNa2w5y3g_qOkOvBNM1g",
    "appid":"wx1234567",
    "offer_id":"12345678",
    "ts":1507530737,
    "zone_id":"1",
    "pf":"android",
    "sig":"1ad64e8dcb2ec1dc486b7fdf01f4a15159fc623dc3422470e51cf6870734726b"
```

2) 对参与开平签名的参数按照key=value的格式，并按照参数名ASCII字典序升序排序如下：
```
stringA="access_token=ACCESSTOKEN&appid=wx1234567&offer_id=12345678&openid=odkx20ENSNa2w5y3g_qOkOvBNM1g&pf=android&sig=1ad64e8dcb2ec1dc486b7fdf01f4a15159fc623dc3422470e51cf6870734726b&ts=1507530737&zone_id=1"
```

3) 拼接uri、method和session_key：
```
stringSignTemp=stringA+"&org_loc=/cgi-bin/midas/getbalance&method=POST&session_key=V7Q38/i2KXaqrQyl2Yx9Hg=="
```

4) 把session_key作为key，使用HMAC-SHA256得到签名。

```
mp_sig=hmac_sha256(key,stringSignTemp)
      ="ff4c5bb39dea1002a8f03be0438724e1a8bcea5ebce8f221f9b9fea3bcf3bf76"
```
