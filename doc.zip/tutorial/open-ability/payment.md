## 虚拟支付

小游戏为开发者提供游戏内虚拟物品的购买服务。

注：目前小游戏虚拟支付能力只支持在安卓Android系统内使用，暂不开放苹果iOS系统内虚拟支付功能。

### 在开通虚拟支付功能前，开发者需完成：

1. 开通小程序微信支付
2. 申请开通小游戏虚拟支付

[wx.requestMidasPayment()](../../document/midas-payment/wx.requestMidasPayment.md) 是我们提供购买游戏币的API：

```javascript
wx.requestMidasPayment(Object options)
```

现阶段我们支持以下价格等级的配置，详见 [wx.requestMidasPayment()](../../document/midas-payment/wx.requestMidasPayment.md) 中关于 buyQuantity 的限制说明

| 价格等级（单位：人民币元） |
| -------------------------- |
| 1                          |
| 3                          |
| 6                          |
| 8                          |
| 12                         |
| 18                         |
| 25                         |
| 30                         |
| 40                         |
| 45                         |
| 50                         |
| 60                         |
| 68                         |
| 73                         |
| 78                         |
| 88                         |
| 98                         |
| 108                        |
| 118                        |
| 128                        |
| 148                        |
| 168                        |
| 188                        |
| 198                        |
| 328                        |
| 648                        |

### 示例代码

```javascript
// 游戏币
wx.requestMidasPayment({
    mode: 'game',
    offerId: '',
    buyQuantity: 10,
    zoneId: 1,
    success() {
        // 支付成功
    },
    fail({ errMsg, errCode }) {
        // 支付失败
        console.log(errMsg, errCode)
    }
})
```

除此之外，我们提供用于测试验证与调试的沙箱测试环境，并相应提供以下API：

| 接口名          | 功能       | 说明                                                     |
| --------------- | ---------- | -------------------------------------------------------- |
| [midasGetBalance](../../document/midas-payment/midasGetBalance.md) | 查询余额   | 查看某个用户的游戏币余额                                 |
| [midasPay](../../document/midas-payment/midasPay.md)        | 扣除游戏币 | 扣除某个用户的游戏币                                     |
| [midasCancelPay](../../document/midas-payment/midasCancelPay.md)  | 取消支付   | 在有效期内的订单，可以通过本接口取消该笔扣除游戏币的订单 |
| [midasPresent](../../document/midas-payment/midasPresent.md)    | 游戏币赠送 | 向某个用户赠送游戏币                                     |

签名算法请参阅 [米大师支付签名](midas-signature.md)