## 获取二维码

小游戏的二维码与小程序有着相同的样式和获取方式。通过后台接口可以获取小游戏的二维码，扫描该二维码可以直接进入小游戏。目前微信支持两种二维码，小程序码（左），小程序二维码（右），如下所示：

![](../images/qrcode.png)

### 获取小程序码

我们推荐生成并使用小程序码，它具有更好的辨识度。目前有两个接口可以生成小程序码，开发者可以根据自己的需要选择合适的接口。

接口A: 适用于需要的码数量较少的业务场景
接口地址：

```
https://api.weixin.qq.com/wxa/getwxacode?access_token=ACCESS_TOKEN
```

获取 access_token 详见[文档](https://mp.weixin.qq.com/wiki?id=mp1421140183)

** POST 参数说明 **

| 参数         | 类型     | 默认值                       | 说明                                       |
| ---------- | ------ | ------------------------- | ---------------------------------------- |
| path       | String |                           | 不能为空，最大长度 128 字节。小游戏没有页面的概念，因此将 query 以 `?a=b&c=d` 形式传给此参数 |
| width      | Int    | 430                       | 二维码的宽度                                   |
| auto_color | Bool   | false                     | 自动配置线条颜色，如果颜色依然是黑色，则说明不建议配置主色调|
| line_color | Object | {"r":"0","g":"0","b":"0"} | auth_color 为 false 时生效，使用 rgb 设置颜色 例如 {"r":"xxx","g":"xxx","b":"xxx"} |

**注意：通过该接口生成的小程序码，永久有效，数量限制见文末说明，请谨慎使用。用户扫描该码进入小程序后，将直接进入 path 对应的页面。**

接口B：适用于需要的码数量极多，或仅临时使用的业务场景

接口地址：

```
https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=ACCESS_TOKEN
```

获取 access_token 详见[文档](https://mp.weixin.qq.com/wiki?id=mp1421140183)

** POST 参数说明 **

| 参数  | 类型 | 默认值 | 说明 |
| ----- | ------ | ------ | ------ |
| scene | String |   | 最大32个可见字符，只支持数字，大小写英文以及部分特殊字符：!#$&'()*+,/:;=?@-._~，其它字符请自行编码为合法字符（因不支持%，中文无法使用 urlencode 处理，请使用其他编码方式）   |
| width      | Int    | 430                       | 二维码的宽度                                   |
| auto_color | Bool   | false                     | 自动配置线条颜色，如果颜色依然是黑色，则说明不建议配置主色调|
| line_color | Object | {"r":"0","g":"0","b":"0"} | auto_color 为 false 时生效，使用 rgb 设置颜色 例如 {"r":"xxx","g":"xxx","b":"xxx"} |


**注意：通过该接口生成的小程序码，永久有效，数量暂无限制。用户扫描该码进入小程序后，开发者需在对应页面获取的码中 scene 字段的值，再做处理逻辑。使用如下代码可以获取到二维码中的 scene 字段的值。调试阶段可以使用开发工具的条件编译自定义参数 scene=xxxx 进行模拟，开发工具模拟时的 scene 的参数值需要进行 urlencode**

```javascript
wx.onShow(function (option) {
    var scene = decodeURIComponent(option.query.scene)
})
```
### 获取小程序二维码

接口 C：适用于需要的码数量较少的业务场景

接口地址：

```
https://api.weixin.qq.com/cgi-bin/wxaapp/createwxaqrcode?access_token=ACCESS_TOKEN
```

获取 access_token 详见 [文档](https://mp.weixin.qq.com/wiki?id=mp1421140183)

** POST 参数说明 **

| 参数         | 类型     | 默认值                       | 说明                                       |
| ---------- | ------ | ------------------------- | ---------------------------------------- |
| path       | String |                           | 不能为空，最大长度 128 字节。小游戏没有页面的概念，因此只需要path的query部分，如 ?a=b&c=d |
| width      | Int    | 430                       | 二维码的宽度                                   |

**注意：通过该接口生成的小程序二维码，永久有效，数量限制见文末说明，请谨慎使用。**

**示例：**

```json
{
    "path": "?query=1", 
    "width": 430
}
```

### Bug & Tip

1. `tip`：通过该接口，仅能生成已发布的小程序的二维码。
2. `tip`：可以在开发者工具预览时生成开发版的带参二维码。
3. `tip`：接口 A 加上接口 C，总共生成的码数量限制为 100,000，请谨慎调用。
4. `tip`: POST 参数需要转成 json 字符串，不支持 form 表单提交。
5. `tip`: auto_color line_color 参数仅对小程序码生效。
