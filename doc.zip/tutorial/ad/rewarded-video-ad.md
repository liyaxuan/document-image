## 激励视频广告

激励视频广告组件是由客户端原生的图片、文本、视频控件组成的，层级最高，会覆盖在上屏 Canvas 上。

开发者可以调用 [wx.createRewardedVideoAd](../../document/ad/wx.createRewardedVideoAd.md) 创建激励视频广告组件。该方法返回的是一个全局单例。

```javascript
let video1 = wx.createRewardedVideoAd({ adUnitId: 'xxxx' })
let video2 = wx.createRewardedVideoAd({ adUnitId: 'xxxx' })
console.log(video1 === video2)
// true
```

激励视频广告组件默认是隐藏的，因此可以提前创建，以提前初始化组件。

```javascript
let rewardedVideoAd = wx.createRewardedVideoAd({ adUnitId: 'xxxx' })
```

### 显示/隐藏

激励视频广告组件默认是隐藏的，需要调用 [RewaredVideoAd.show()]() 进行显示。

```javascript
bannerAd.show()
```

只有在用户点击激励视频广告组件上的 `关闭广告` 按钮时，广告才会关闭。开发者不可控制激励视频广告组件的隐藏。

### 广告拉取成功与失败

激励视频广告组件是自动拉取广告并进行更新的。在组件创建后会拉取一次广告，用户点击 `关闭广告` 后会去拉取下一条广告。  

如果拉取成功。[RewardedVideoAd.onLoad()](../../document/ad/RewardedVideoAd.onLoad.md) 会执行，[RewardedVideoAd.show()](../../document/ad/RewardedVideoAd.show.md) 返回的 Promise 也会是一个 resolved Promise。两者的回调函数中都没有参数传递。

```javascript
rewardedVideoAd.onLoad(() => {
  console.log('banner 广告加载成功')
})

rewardedVideoAd.show()
.then(() => console.log('banner 广告显示'))
```

如果拉取失败，通过 [RewardedVideoAd.onError()](../../document/ad/RewardedVideoAd.onError.md) 注册的回调函数会执行，回调函数的参数是一个包含错误信息的对象。

```javascript
rewardedVideoAd.onError(err => {
  console.log(err)
})
```

[RewardedVideoAd.show()](../../document/ad/RewardedVideoAd.show.md) 返回的 Promise 也会是一个 rejected Promise。

```javascript
rewardedVideoAd.show()
.catch(err => console.log(err))
```

### 拉取失败，重新拉取

如果组件的某次自动拉取失败，那么之后调用的 show() 将会被 reject。此时可以调用 [RewardedVideoAd.load()](../../document/ad/RewardedVideoAd.load.md) 手动重新拉取广告。

```javascript
rewardedVideoAd.show()
.catch(err => {
    rewardedVideoAd.load()
    .then(() => rewardedVideoAd.show())
})
```

如果组件的自动拉取是成功的，那么调用 load() 方法会直接返回一个 resolved Promise，而不会去拉取广告。

```javascript
rewardedVideoAd.load()
.then(() => rewardedVideoAd.show())
```

### 监听用户关闭广告

只有在用户点击激励视频广告组件上的 `关闭广告` 按钮时，广告才会关闭。这个事件可以通过 [RewardedVideoAd.onClose()](../../document/ad/RewardedVideoAd.onClose.md) 监听。  

`关闭广告` 按钮只有在广告视频完全播放完以后才会出现，`onClose` 触发时可以认为用户已经看完了广告。

```javascript
rewardedVideoAd.onClose(() => {
  // 用户点击了【关闭广告】按钮
})
```