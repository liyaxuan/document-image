### Worker.postMessage(Object message)

向主线程/Worker 线程发送的消息。

#### 参数

##### Object message

需要发送的消息，必须是一个可序列化的 JavaScript 对象。

