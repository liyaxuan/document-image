### Worker.onMessage(function callback)

监听接收主线程/Worker 线程向当前线程发送的消息

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| message  | Object | 接收主线程/Worker 线程向当前线程发送的消息 |   |

