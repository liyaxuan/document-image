### Worker wx.createWorker()

创建一个 Worker 线程，目前限制最多只能创建一个 Worker，创建下一个 Worker 前请调用 [Worker.terminate](Worker.terminate.md)

#### 返回值

##### [Worker](Worker.md)

Worker 对象

