### Worker.terminate()

结束当前 worker 线程，仅限在主线程 worker 对象上调用。

