### Worker

Worker 实例，可通过 [wx.createWorker](wx.createWorker.md) 接口获取实例。

#### 方法

##### [Worker.postMessage(Object message)](Worker.postMessage.md)

向主线程/Worker 线程发送的消息。

##### [Worker.terminate()](Worker.terminate.md)

结束当前 worker 线程，仅限在主线程 worker 对象上调用。

##### [Worker.onMessage(function callback)](Worker.onMessage.md)

监听接收主线程/Worker 线程向当前线程发送的消息

##### [Worker.postMessage(Object message)](Worker.postMessage.md)

向主线程/Worker 线程发送的消息。

##### [Worker.terminate()](Worker.terminate.md)

结束当前 worker 线程，仅限在主线程 worker 对象上调用。

