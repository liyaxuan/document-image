### FileSystemManager.rmdir(Object object)

删除目录

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| dirPath | string |  | 是 | 要删除的目录路径 |   |
| recursive | boolean | false | 否 | 是否递归删除目录。如果为 true，则删除该目录和该目录下的所有子目录以及文件。 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

#### fail 回调函数

##### 参数

###### Object res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| errMsg  | string | 错误信息 |   |

**res.errMsg 的合法值**

| 值 | 说明 |
| -- | ---- |
| fail no such file or directory ${dirPath} | 目录不存在 |
| fail directory not empty | 目录不为空 |
| fail permission denied, open ${dirPath} | 指定的 dirPath 路径没有写权限 |

