### FileSystemManager.unlinkSync(string filePath)

FileSystemManager.unlink 的同步版本

#### 参数

##### string filePath

要删除的文件路径

#### 错误

| errMsg | 说明 |
| -- | ---- |
| fail permission denied, open ${path} | 指定的 path 路径没有读权限 |
| fail no such file or directory ${path} | 文件不存在 |
| fail operation not permitted, unlink ${filePath} | 传入的 filePath 是一个目录 |

