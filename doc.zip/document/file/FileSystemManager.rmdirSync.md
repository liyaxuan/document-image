### FileSystemManager.rmdirSync(string dirPath, boolean recursive)

FileSystemManager.rmdir 的同步版本

#### 参数

##### string dirPath

要删除的目录路径

##### boolean recursive

是否递归删除目录。如果为 true，则删除该目录和该目录下的所有子目录以及文件。

#### 错误

| errMsg | 说明 |
| -- | ---- |
| fail no such file or directory ${dirPath} | 目录不存在 |
| fail directory not empty | 目录不为空 |
| fail permission denied, open ${dirPath} | 指定的 dirPath 路径没有写权限 |

