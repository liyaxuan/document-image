### boolean Stats.isDirectory()

判断当前文件是否一个目录

#### 返回值

##### boolean

表示当前文件是否一个目录

