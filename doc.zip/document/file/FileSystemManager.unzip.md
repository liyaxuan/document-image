### FileSystemManager.unzip(Object object)

解压文件

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| zipFilePath | string |  | 是 | 源文件路径，只可以是 zip 压缩文件 |   |
| targetPath | string |  | 是 | 目标目录路径 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

