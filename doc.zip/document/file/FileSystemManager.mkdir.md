### FileSystemManager.mkdir(Object object)

创建目录

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| dirPath | string |  | 是 | 创建的目录路径 |   |
| recursive | boolean | false | 否 | 是否在递归创建该目录的上级目录后再创建该目录。如果对应的上级目录已经存在，则不创建该上级目录。如 dirPath 为 a/b/c/d 且 recursive 为 true，将创建 a 目录，再在 a 目录下创建 b 目录，以此类推直至创建 a/b/c 目录下的 d 目录。 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

#### fail 回调函数

##### 参数

###### Object res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| errMsg  | string | 错误信息 |   |

**res.errMsg 的合法值**

| 值 | 说明 |
| -- | ---- |
| fail no such file or directory ${dirPath} | 上级目录不存在 |
| fail permission denied, open ${dirPath} | 指定的 filePath 路径没有写权限 |
| fail file already exists ${dirPath} | 有同名文件或目录 |

