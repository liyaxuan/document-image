### FileSystemManager wx.getFileSystemManager()

获取全局唯一的文件管理器

#### 返回值

##### [FileSystemManager](FileSystemManager.md)

文件管理器

