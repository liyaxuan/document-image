### boolean Stats.isFile()

判断当前文件是否一个普通文件

#### 返回值

##### boolean

表示当前文件是否一个普通文件

