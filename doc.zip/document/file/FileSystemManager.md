### FileSystemManager

文件管理器

#### 方法

##### [FileSystemManager.mkdirSync(string dirPath, boolean recursive)](FileSystemManager.mkdirSync.md)

FileSystemManager.mkdir 的同步版本

##### [FileSystemManager.mkdir(Object object)](FileSystemManager.mkdir.md)

创建目录

##### [Array.&lt;string&gt; FileSystemManager.readdirSync(string dirPath)](FileSystemManager.readdirSync.md)

FileSystemManager.readdir 的同步版本

##### [FileSystemManager.readdir(Object object)](FileSystemManager.readdir.md)

读取目录内文件列表

##### [FileSystemManager.writeFileSync(string filePath, string|ArrayBuffer data, string encoding)](FileSystemManager.writeFileSync.md)

FileSystemManager.writeFile 的同步版本

##### [FileSystemManager.writeFile(Object object)](FileSystemManager.writeFile.md)

写文件

##### [FileSystemManager.unzip(Object object)](FileSystemManager.unzip.md)

解压文件

##### [FileSystemManager.renameSync(string oldPath, string newPath)](FileSystemManager.renameSync.md)

FileSystemManager.rename 的同步版本

##### [FileSystemManager.rename(Object object)](FileSystemManager.rename.md)

重命名文件，可以把文件从 oldPath 移动到 newPath

##### [FileSystemManager.unlinkSync(string filePath)](FileSystemManager.unlinkSync.md)

FileSystemManager.unlink 的同步版本

##### [FileSystemManager.unlink(Object object)](FileSystemManager.unlink.md)

删除文件

##### [FileSystemManager.rmdirSync(string dirPath, boolean recursive)](FileSystemManager.rmdirSync.md)

FileSystemManager.rmdir 的同步版本

##### [FileSystemManager.rmdir(Object object)](FileSystemManager.rmdir.md)

删除目录

##### [Stats FileSystemManager.statSync(string path)](FileSystemManager.statSync.md)

FileSystemManager.stat 的同步版本

##### [Stats FileSystemManager.stat(Object object)](FileSystemManager.stat.md)

获取文件 Stats 对象

##### [string|ArrayBuffer FileSystemManager.readFileSync(string filePath, string encoding)](FileSystemManager.readFileSync.md)

FileSystemManager.readFile 的同步版本

##### [FileSystemManager.readFile(Object object)](FileSystemManager.readFile.md)

读取本地文件内容

