### FileSystemManager.accessSync(string path)

FileSystemManager.access 的同步版本

#### 参数

##### string path

要判断是否存在的文件/目录路径

#### 错误

| errMsg | 说明 |
| -- | ---- |
| fail no such file or directory ${path} | 文件/目录不存在 |

