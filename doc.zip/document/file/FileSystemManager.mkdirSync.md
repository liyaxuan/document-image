### FileSystemManager.mkdirSync(string dirPath, boolean recursive)

FileSystemManager.mkdir 的同步版本

#### 参数

##### string dirPath

创建的目录路径

##### boolean recursive

是否在递归创建该目录的上级目录后再创建该目录。如果对应的上级目录已经存在，则不创建该上级目录。如 dirPath 为 a/b/c/d 且 recursive 为 true，将创建 a 目录，再在 a 目录下创建 b 目录，以此类推直至创建 a/b/c 目录下的 d 目录。

#### 错误

| errMsg | 说明 |
| -- | ---- |
| fail no such file or directory ${dirPath} | 上级目录不存在 |
| fail permission denied, open ${dirPath} | 指定的 filePath 路径没有写权限 |
| fail file already exists ${dirPath} | 有同名文件或目录 |

