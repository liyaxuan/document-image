### clearInterval(number intervalID)

可取消由 setInterval() 方法设置的定时器。

#### 参数

##### number intervalID

要取消的定时器的 ID

