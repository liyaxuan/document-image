### clearTimeout(number timeoutID)

可取消由 setTimeout() 方法设置的定时器。

#### 参数

##### number timeoutID

要取消的定时器的 ID

