### Performance

性能管理器

#### 方法

##### [number Performance.now()](Performance.now.md)

可以获取当前时间以微秒为单位的时间戳

##### [number Performance.now()](Performance.now.md)

可以获取当前时间以微秒为单位的时间戳

