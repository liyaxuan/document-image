### Performance wx.getPerformance()

获取性能管理器

#### 返回值

##### [Performance](Performance.md)

一个性能管理器对象

