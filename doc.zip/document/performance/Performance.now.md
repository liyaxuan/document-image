### number Performance.now()

可以获取当前时间以微秒为单位的时间戳

#### 返回值

##### number

时间戳

