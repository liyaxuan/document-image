### onMemoryWarning(function callback)

> 基础库 2.0.0 开始支持，低版本需做兼容处理

监听内存不足告警

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| level  | Number | 内存告警等级，只有 Android 才有，对应系统宏定义 |   |

**level 的合法值**

| 值 | 说明 |
| -- | ---- |
| 10 | TRIM_MEMORY_RUNNING_LOW |
| 15 | TRIM_MEMORY_RUNNING_CRITICAL |

