### wx.offShareAppMessage(function callback)

取消监听用户点击右上角菜单的“转发”按钮时触发的事件

#### 参数

##### function callback

监听事件的回调函数

