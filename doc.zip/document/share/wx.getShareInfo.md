### wx.getShareInfo(Object object)

> 基础库 1.1.0 开始支持，低版本需做兼容处理

获取转发详细信息

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| shareTicket | string |  | 是 | shareTicket |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

#### success 回调函数

##### 参数

###### Object res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| errMsg  | string | 错误信息 |   |
| encryptedData  | string | 包括敏感数据在内的完整转发信息的加密数据，详细见[加密数据解密算法](../../tutorial/open-ability/signature.md) |   |
| iv  | string | 加密算法的初始向量，详细见[加密数据解密算法](../../tutorial/open-ability/signature.md) |   |

#### 示例代码

encryptedData 解密后为以下 json 结构，详见[加密数据解密算法](../../tutorial/open-ability/signature.md)
```javascript
{
    "openGId": "OPENGID"
}
```

