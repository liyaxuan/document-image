### wx.onShareAppMessage(function callback)

监听用户点击右上角菜单的“转发”按钮时触发的事件

#### 参数

##### function callback

监听事件的回调函数

#### callback 回调函数

##### 返回值

###### ShareOption

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| title  | string | 转发标题，不传则默认使用当前小游戏的昵称。 |   |
| imageUrl  | string | 转发显示图片的链接，可以是网络图片路径或本地图片文件路径或相对代码包根目录的图片文件路径。 |   |
| query  | string | 查询字符串，必须是 key1=val1&key2=val2 的格式。从这条转发消息进入后，可通过 wx.onLaunch() 或 wx.onShow 获取启动参数中的 query。 |   |

