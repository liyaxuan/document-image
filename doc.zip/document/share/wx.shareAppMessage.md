### wx.shareAppMessage(Object object)

主动拉起转发，进入选择通讯录界面。

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| title | string |  | 否 | 转发标题，不传则默认使用当前小游戏的昵称。 |   |
| imageUrl | string |  | 否 | 转发显示图片的链接，可以是网络图片路径或本地图片文件路径或相对代码包根目录的图片文件路径。 |   |
| query | string |  | 否 | 查询字符串，从这条转发消息进入后，可通过 wx.onLaunch() 或 wx.onShow 获取启动参数中的 query。必须是 key1=val1&key2=val2 的格式。 |   |

