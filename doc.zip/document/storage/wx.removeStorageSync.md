### wx.removeStorageSync(string key)

wx.removeStorage 的同步版本

#### 参数

##### string key

本地缓存中指定的 key

