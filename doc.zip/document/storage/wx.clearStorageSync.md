### wx.clearStorageSync()

wx.clearStorage 的同步版本

