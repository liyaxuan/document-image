### Object wx.getStorageInfoSync()

wx.getStorageInfo 的同步版本

#### 返回值

##### Object object

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| keys  | Array.&lt;string&gt; | 当前 storage 中所有的 key |   |
| currentSize  | number | 当前占用的空间大小, 单位 KB |   |
| limitSize  | number | 限制的空间大小，单位 KB |   |

