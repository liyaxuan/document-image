### Object|string wx.getStorageSync(string key)

wx.getStorage 的同步版本

#### 参数

##### string key

本地缓存中指定的 key

#### 返回值

##### Object|string data

key对应的内容

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |

