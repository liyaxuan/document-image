### wx.setStorageSync(string key, Object|string data)

wx.setStorage 的同步版本

#### 参数

##### string key

本地缓存中指定的 key

##### Object|string data

需要存储的内容

