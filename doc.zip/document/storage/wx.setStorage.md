### wx.setStorage(Object object)

将数据存储在本地缓存中指定的 key 中，会覆盖掉原来该 key 对应的内容。

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| key | string |  | 是 | 本地缓存中指定的 key |   |
| data | Object/string |  | 是 | 需要存储的内容 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

