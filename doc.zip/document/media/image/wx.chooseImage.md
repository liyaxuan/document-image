### wx.chooseImage(Object object)

从本地相册选择图片或使用相机拍照。

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| count | number |  | 是 |  |   |
| sizeType | Array.&lt;string&gt; |  | 是 | 所选的图片的尺寸 |   |
| sourceType | Array.&lt;string&gt; |  | 是 | 选择图片的来源 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

**object.sizeType 的合法值**

| 值 | 说明 |
| -- | ---- |
| ['original'] | 原图 |
| ['compressed'] | 压缩图 |
| ['original', 'compressed'] | 原图和压缩图都有 |

**object.sourceType 的合法值**

| 值 | 说明 |
| -- | ---- |
| ['album'] | 从相册选图 |
| ['camera'] | 使用相机 |
| ['album', 'camera'] | 原图和压缩图都有 |

#### success 回调函数

##### 参数

###### Object res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| tempFilePaths  | Array.&lt;string&gt; | 图片的本地文件路径列表 |   |
| tempFiles  | Array.&lt;[ImageFile](ImageFile.md)&gt; | 图片的本地文件列表，每一项是一个 File 对象 | 1.2.0 |

