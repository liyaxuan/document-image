### wx.previewImage(Object object)

预览图片

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| current | string | urls 的第一张 | 否 | 当前显示图片的链接 |   |
| urls | Array.&lt;string&gt; |  | 是 | 需要预览的图片链接列表 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

