### ImageFile

#### 属性

##### string path

本地文件路径

##### number size

本地文件大小，单位 B

