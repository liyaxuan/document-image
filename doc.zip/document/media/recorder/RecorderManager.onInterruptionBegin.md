### RecorderManager.onInterruptionBegin(function callback)

> 基础库 2.2.0 开始支持，低版本需做兼容处理

监听录音因为受到系统占用而被中断开始，以下场景会触发此事件：微信语音聊天、微信视频聊天。此事件触发后，录音会被暂停。pause 事件在此事件后触发

#### 参数

#####  callback

监听事件的回调函数

