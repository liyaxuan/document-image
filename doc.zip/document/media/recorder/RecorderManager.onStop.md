### RecorderManager.onStop(function callback)

监听录音结束事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| tempFilePath  | string | 录音文件的临时路径 |   |

