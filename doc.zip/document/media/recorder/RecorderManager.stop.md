### RecorderManager.stop()

停止录音

