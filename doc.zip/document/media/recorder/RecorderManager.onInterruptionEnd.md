### RecorderManager.onInterruptionEnd(function callback)

> 基础库 2.2.0 开始支持，低版本需做兼容处理

监听录音中断结束，在收到 interruptionBegin 事件之后，小程序内所有录音会暂停，收到此事件之后才可再次录音成功。

#### 参数

#####  callback

监听事件的回调函数

