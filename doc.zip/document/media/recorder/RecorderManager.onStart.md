### RecorderManager.onStart(function callback)

监听录音开始事件

#### 参数

#####  callback

监听事件的回调函数

