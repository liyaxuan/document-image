### RecorderManager.onResume(function callback)

监听录音继续事件

#### 参数

#####  callback

监听事件的回调函数

