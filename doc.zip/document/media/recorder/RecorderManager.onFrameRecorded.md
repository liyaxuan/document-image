### RecorderManager.onFrameRecorded(function callback)

监听已录制完指定帧大小的文件事件。如果设置了 frameSize，则会回调此事件。

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| frameBuffer  | ArrayBuffer | 录音分片数据 |   |
| isLastFrame  | boolean | 当前帧是否正常录音结束前的最后一帧 |   |

