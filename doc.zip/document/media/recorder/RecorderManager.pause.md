### RecorderManager.pause()

暂停录音

