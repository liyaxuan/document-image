### RecorderManager wx.getRecorderManager()

> 基础库 1.6.0 开始支持，低版本需做兼容处理

获取全局唯一的 RecorderManager

#### 返回值

##### [RecorderManager](RecorderManager.md)

