### InnerAudioContext wx.createInnerAudioContext()

创建一个 InnerAudioContext 实例

#### 返回值

##### [InnerAudioContext](InnerAudioContext.md)

