### InnerAudioContext.offWaiting(function callback)

取消监听音频加载中事件，当音频因为数据不足，需要停下来加载时会触发

#### 参数

#####  callback

取消监听事件的回调函数

