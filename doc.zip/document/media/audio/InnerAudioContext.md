### InnerAudioContext

InnerAudioContext 实例，可通过 wx.createInnerAudioContext 接口获取实例。

#### 属性

##### string src

音频资源的地址

##### boolean autoplay

是否自动播放

##### boolean loop

是否循环播放

##### boolean obeyMuteSwitch

是否遵循系统静音开关，当此参数为 false 时，即使用户打开了静音开关，也能继续发出声音

##### number duration

当前音频的长度，单位 s。只有在当前有合法的 src 时返回

##### number currentTime

当前音频的播放位置，单位 s。只有在当前有合法的 src 时返回，时间不取整，保留小数点后 6 位

##### boolean paused

当前是是否暂停或停止状态，true 表示暂停或停止，false 表示正在播放

##### number buffered

音频缓冲的时间点，仅保证当前播放时间点到此时间点内容已缓冲

##### number volume

音量。范围 0~1。

#### 方法

##### [InnerAudioContext.play()](InnerAudioContext.play.md)

播放

##### [InnerAudioContext.pause()](InnerAudioContext.pause.md)

暂停。暂停后的音频再播放会从暂停处开始播放

##### [InnerAudioContext.stop()](InnerAudioContext.stop.md)

停止。停止后的音频再播放会从头开始播放。

##### [InnerAudioContext.seek(number position)](InnerAudioContext.seek.md)

跳转到指定位置，单位 s

##### [InnerAudioContext.destroy()](InnerAudioContext.destroy.md)

销毁当前实例

##### [InnerAudioContext.onCanplay(function callback)](InnerAudioContext.onCanplay.md)

监听音频进入可以播放状态的事件

##### [InnerAudioContext.offCanplay(function callback)](InnerAudioContext.offCanplay.md)

取消监听音频进入可以播放状态的事件

##### [InnerAudioContext.onPlay(function callback)](InnerAudioContext.onPlay.md)

监听音频播放事件

##### [InnerAudioContext.offPlay(function callback)](InnerAudioContext.offPlay.md)

取消监听音频播放事件

##### [InnerAudioContext.onPause(function callback)](InnerAudioContext.onPause.md)

监听音频暂停事件

##### [InnerAudioContext.offPause(function callback)](InnerAudioContext.offPause.md)

取消监听音频暂停事件

##### [InnerAudioContext.onStop(function callback)](InnerAudioContext.onStop.md)

监听音频停止事件

##### [InnerAudioContext.offStop(function callback)](InnerAudioContext.offStop.md)

取消监听音频停止事件

##### [InnerAudioContext.onEnded(function callback)](InnerAudioContext.onEnded.md)

监听音频自然播放至结束的事件

##### [InnerAudioContext.offEnded(function callback)](InnerAudioContext.offEnded.md)

取消监听音频自然播放至结束的事件

##### [InnerAudioContext.onTimeUpdate(function callback)](InnerAudioContext.onTimeUpdate.md)

监听音频播放进度更新事件

##### [InnerAudioContext.offTimeUpdate(function callback)](InnerAudioContext.offTimeUpdate.md)

取消监听音频播放进度更新事件

##### [InnerAudioContext.onError(function callback)](InnerAudioContext.onError.md)

监听音频播放错误事件

##### [InnerAudioContext.offError(function callback)](InnerAudioContext.offError.md)

取消监听音频播放错误事件

##### [InnerAudioContext.onWaiting(function callback)](InnerAudioContext.onWaiting.md)

监听音频加载中事件，当音频因为数据不足，需要停下来加载时会触发

##### [InnerAudioContext.offWaiting(function callback)](InnerAudioContext.offWaiting.md)

取消监听音频加载中事件，当音频因为数据不足，需要停下来加载时会触发

##### [InnerAudioContext.onSeeking(function callback)](InnerAudioContext.onSeeking.md)

监听音频进行跳转操作的事件

##### [InnerAudioContext.offSeeking(function callback)](InnerAudioContext.offSeeking.md)

取消监听音频进行跳转操作的事件

##### [InnerAudioContext.onSeeked(function callback)](InnerAudioContext.onSeeked.md)

监听音频完成跳转操作的事件

##### [InnerAudioContext.offSeeked(function callback)](InnerAudioContext.offSeeked.md)

取消监听音频完成跳转操作的事件

##### [InnerAudioContext.play()](InnerAudioContext.play.md)

播放

##### [InnerAudioContext.pause()](InnerAudioContext.pause.md)

暂停。暂停后的音频再播放会从暂停处开始播放

##### [InnerAudioContext.stop()](InnerAudioContext.stop.md)

停止。停止后的音频再播放会从头开始播放。

##### [InnerAudioContext.seek(number position)](InnerAudioContext.seek.md)

跳转到指定位置，单位 s

##### [InnerAudioContext.destroy()](InnerAudioContext.destroy.md)

销毁当前实例

##### [InnerAudioContext wx.createInnerAudioContext()](wx.createInnerAudioContext.md)

创建一个 InnerAudioContext 实例

