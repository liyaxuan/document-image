### InnerAudioContext.onStop(function callback)

监听音频停止事件

#### 参数

#####  callback

监听事件的回调函数

