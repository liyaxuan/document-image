### InnerAudioContext.stop()

停止。停止后的音频再播放会从头开始播放。

