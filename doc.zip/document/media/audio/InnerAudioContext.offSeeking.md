### InnerAudioContext.offSeeking(function callback)

取消监听音频进行跳转操作的事件

#### 参数

#####  callback

取消监听事件的回调函数

