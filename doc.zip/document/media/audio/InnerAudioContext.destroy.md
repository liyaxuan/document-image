### InnerAudioContext.destroy()

销毁当前实例

