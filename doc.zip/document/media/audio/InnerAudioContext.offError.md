### InnerAudioContext.offError(function callback)

取消监听音频播放错误事件

#### 参数

#####  callback

取消监听事件的回调函数

