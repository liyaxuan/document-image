### InnerAudioContext.onError(function callback)

监听音频播放错误事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| errCode  | number |  |   |

**errCode 的合法值**

| 值 | 说明 |
| -- | ---- |
| 10001 | 系统错误 |
| 10002 | 网络错误 |
| 10003 | 文件错误 |
| 10004 | 格式错误 |
| -1 | 未知错误 |

