### InnerAudioContext.offEnded(function callback)

取消监听音频自然播放至结束的事件

#### 参数

#####  callback

取消监听事件的回调函数

