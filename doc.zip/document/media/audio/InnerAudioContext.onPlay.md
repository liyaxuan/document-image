### InnerAudioContext.onPlay(function callback)

监听音频播放事件

#### 参数

#####  callback

监听事件的回调函数

