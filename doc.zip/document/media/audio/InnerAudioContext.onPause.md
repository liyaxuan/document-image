### InnerAudioContext.onPause(function callback)

监听音频暂停事件

#### 参数

#####  callback

监听事件的回调函数

