### InnerAudioContext.offStop(function callback)

取消监听音频停止事件

#### 参数

#####  callback

取消监听事件的回调函数

