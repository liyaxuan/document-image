### InnerAudioContext.onTimeUpdate(function callback)

监听音频播放进度更新事件

#### 参数

#####  callback

监听事件的回调函数

