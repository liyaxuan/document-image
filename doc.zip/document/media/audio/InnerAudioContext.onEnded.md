### InnerAudioContext.onEnded(function callback)

监听音频自然播放至结束的事件

#### 参数

#####  callback

监听事件的回调函数

