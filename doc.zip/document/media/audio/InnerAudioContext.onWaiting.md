### InnerAudioContext.onWaiting(function callback)

监听音频加载中事件，当音频因为数据不足，需要停下来加载时会触发

#### 参数

#####  callback

监听事件的回调函数

