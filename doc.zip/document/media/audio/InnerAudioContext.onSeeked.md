### InnerAudioContext.onSeeked(function callback)

监听音频完成跳转操作的事件

#### 参数

#####  callback

监听事件的回调函数

