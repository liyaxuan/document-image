### InnerAudioContext.seek(number position)

跳转到指定位置，单位 s

#### 参数

##### number position

跳转的时间

