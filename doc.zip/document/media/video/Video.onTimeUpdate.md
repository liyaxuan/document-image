### Video.onTimeUpdate(function callback)

监听视频播放进度更新事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| position  | number | 当前的播放位置，单位为秒 |   |
| duration  | number | 视频的总时长，单位为秒 |   |

