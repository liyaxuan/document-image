### Video.onPlay(function callback)

监听视频播放事件

#### 参数

#####  callback

监听事件的回调函数

