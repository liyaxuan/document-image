### Video.onError(function callback)

监听视频错误事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| errMsg  | string | 错误信息 |   |

**errMsg 的合法值**

| 值 | 说明 |
| -- | ---- |
| MEDIA_ERR_NETWORK | 当下载时发生错误 |
| MEDIA_ERR_DECODE | 当解码时发生错误 |
| MEDIA_ERR_SRC_NOT_SUPPORTED | video 的 src 属性是不支持的资源类型 |

