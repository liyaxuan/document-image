### Promise Video.stop()

停止视频

#### 返回值

##### Promise

视频停止完成的 Promise

