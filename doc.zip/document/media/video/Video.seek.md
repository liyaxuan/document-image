### Promise Video.seek(number time)

视频跳转

#### 参数

##### number time

视频跳转到指定位置，单位为 s 秒

#### 返回值

##### Promise

视频跳转完成的 Promise

