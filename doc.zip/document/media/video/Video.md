### Video

视频对象

#### 属性

##### number x

视频的左上角横坐标

##### number y

视频的左上角纵坐标

##### number width

视频的宽度

##### number height

视频的高度

##### number src

视频的资源地址

##### number poster

视频的封面

##### number initialTime

视频的初始播放位置，单位为 s 秒

##### number playbackRate

视频的播放速率，有效值有 0.5、0.8、1.0、1.25、1.5

##### number live

视频是否为直播

##### number objectFit

视频的缩放模式

##### number controls

视频是否显示控件

##### number autoplay

视频是否自动播放

##### number loop

视频是否是否循环播放

##### number muted

视频是否禁音播放

##### function onwaiting

视频开始缓冲时触发的回调函数

##### function onplay

视频开始播放时触发的回调函数

##### function onpause

视频暂停时触发的回调函数

##### function onended

视频播放到末尾时触发的回调函数

##### function ontimeupdate

每当视频播放进度更新时触发的回调函数

##### function onerror

视频发生错误时触发的回调函数

#### 方法

##### [Video.destroy()](Video.destroy.md)

销毁视频

##### [Promise Video.play()](Video.play.md)

播放视频

##### [Promise Video.pause()](Video.pause.md)

暂停视频

##### [Promise Video.stop()](Video.stop.md)

停止视频

##### [Promise Video.seek(number time)](Video.seek.md)

视频跳转

##### [Promise Video.requestFullScreen()](Video.requestFullScreen.md)

视频全屏

##### [Promise Video.exitFullScreen()](Video.exitFullScreen.md)

视频退出全屏

##### [Video.onWaiting(function callback)](Video.onWaiting.md)

监听视频缓冲事件

##### [Video.offWaiting(function callback)](Video.offWaiting.md)

取消监听视频缓冲事件

##### [Video.onPlay(function callback)](Video.onPlay.md)

监听视频播放事件

##### [Video.offPlay(function callback)](Video.offPlay.md)

取消监听视频播放事件

##### [Video.onPause(function callback)](Video.onPause.md)

监听视频暂停事件

##### [Video.offPause(function callback)](Video.offPause.md)

取消监听视频暂停事件

##### [Video.onEnded(function callback)](Video.onEnded.md)

监听视频播放到末尾事件

##### [Video.offEnded(function callback)](Video.offEnded.md)

取消监听视频播放到末尾事件

##### [Video.onTimeUpdate(function callback)](Video.onTimeUpdate.md)

监听视频播放进度更新事件

##### [Video.offTimeUpdate(function callback)](Video.offTimeUpdate.md)

取消监听视频播放进度更新事件

##### [Video.onError(function callback)](Video.onError.md)

监听视频错误事件

##### [Video.offError(function callback)](Video.offError.md)

取消监听视频错误事件

##### [Promise Video.play()](Video.play.md)

播放视频

##### [Promise Video.pause()](Video.pause.md)

暂停视频

##### [Promise Video.stop()](Video.stop.md)

停止视频

##### [Promise Video.seek(number time)](Video.seek.md)

视频跳转

##### [Promise Video.requestFullScreen()](Video.requestFullScreen.md)

视频全屏

##### [Promise Video.exitFullScreen()](Video.exitFullScreen.md)

视频退出全屏

##### [Video wx.createVideo(Object object)](wx.createVideo.md)

创建视频

