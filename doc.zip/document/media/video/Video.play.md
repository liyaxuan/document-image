### Promise Video.play()

播放视频

#### 返回值

##### Promise

视频播放完成的 Promise

