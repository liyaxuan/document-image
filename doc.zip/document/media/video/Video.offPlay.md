### Video.offPlay(function callback)

取消监听视频播放事件

#### 参数

#####  callback

取消监听事件的回调函数

