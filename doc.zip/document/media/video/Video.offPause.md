### Video.offPause(function callback)

取消监听视频暂停事件

#### 参数

#####  callback

取消监听事件的回调函数

