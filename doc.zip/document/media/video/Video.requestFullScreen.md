### Promise Video.requestFullScreen()

视频全屏

#### 返回值

##### Promise

视频全屏完成的 Promise

