### Promise Video.pause()

暂停视频

#### 返回值

##### Promise

视频暂停完成的 Promise

