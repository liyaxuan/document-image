### Video.onEnded(function callback)

监听视频播放到末尾事件

#### 参数

#####  callback

监听事件的回调函数

