### Promise Video.exitFullScreen()

视频退出全屏

#### 返回值

##### Promise

视频退出全屏完成的 Promise

