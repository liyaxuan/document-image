### Video.offWaiting(function callback)

取消监听视频缓冲事件

#### 参数

#####  callback

取消监听事件的回调函数

