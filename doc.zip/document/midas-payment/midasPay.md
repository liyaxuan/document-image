
### midasPay

开通了虚拟支付的小游戏，可以通过本接口扣除某个用户的游戏币。 **由于可能存在接口调用超时或返回系统失败，但是游戏币实际已经扣除的情况，所以当该接口返回系统失败时，可以用相同的bill_no再次调用本接口，直到返回非系统失败为止，不会重复扣款，也可以调用取消支付接口取消本次扣款。**

#### 正式环境
```
POST https://api.weixin.qq.com/cgi-bin/midas/pay?access_token=ACCESS_TOKEN
```
#### 沙箱环境
```
POST https://api.weixin.qq.com/cgi-bin/midas/sandbox/pay?access_token=ACCESS_TOKEN
```

#### 参数
| 参数 | 类型 | 默认值 | 是否必填 | 说明 |
| ---- | ---- | ------ | -------- | ---- |
| openid | string |  | 是 | 用户唯一标识符 |
| appid | string |  | 是 | 小程序 appId |
| offer_id | string |  | 是 | 米大师分配的offer_id |
| ts | number |  | 是 | UNIX 时间戳，单位是秒 |
| zone_id | string |  | 是 | 游戏服务器大区id,游戏不分大区则默认zoneId ="1",String类型。如过应用选择支持角色，则角色ID接在分区ID号后用"_"连接。 |
| pf | string |  | 是 | 平台 安卓：android |
| user_ip | string |  | 否 | 用户外网 IP |
| amt | number |  | 是 | 扣除游戏币数量，不能为 0 |
| bill_no | string |  | 是 | 订单号，业务需要保证全局唯一；相同的订单号不会重复扣款。长度不超过63，只能是数字、大小写字母_-|*@ |
| pay_item | string |  | 否 | 道具名称 |
| app_remark | string |  | 否 | 备注。会写到账户流水 |
| sig | string |  | 是 | 以上所有参数（含可选最多11个）+uri+米大师密钥，用 HMAC-SHA256签名，详见 [米大师支付签名算法](../../tutorial/open-ability/midas-signature.md) |
| access_token | string |  | 是 | 接口调用凭证 |
| mp_sig | string |  | 是 | 以上所有参数（含可选最多13个）+uri+session_key，用 HMAC-SHA256签名，详见 [米大师支付签名算法](../../tutorial/open-ability/midas-signature.md) |

#### 返回值
| 参数 | 类型 | 说明 |
| ---- | ---- | ---- |
| errcode | number | 错误码 |
| errmsg | number | 错误信息 |
| bill_no | string | 订单号，有效期是 48 小时 |
| balance | number | 预扣后的余额 |
| used_gen_balance | number | 本次扣的赠送币的余额 |

**errcode 的合法值**

| 值 | 说明 |
| -- | ---- |
| 0 | 请求成功 |
| -1 | 系统繁忙，此时请开发者稍候再试 |
| 90009 | mp_sig签名错误 |
| 90010 | 用户未登录或登录态已过期 |
| 90011 | sig签名错误 |
| 90012 | 订单已存在 |
| 90013 | 余额不足 |
| 90017 | 没有调用接口的权限 |
| 90018 | 参数错误 |

#### POST 数据格式：JSON

 ```
 {
     "openid":"odkx20ENSNa2w5y3g_qOkOvBNM1g",
     "appid":"wx1234567",
     "offer_id":"12345678",
     "ts":1507530737,
     "zone_id":"1",
     "pf":"android",
     "amt":123,
     "bill_no":"BillNo_123",
     "sig":"f705c7351830125282ffc6d3c22c81db19b50a748f60f7c8f267e59152941d83",
     "mp_sig":"168704ac52eea6da27e0d76fd659cd8d628457dd680459a57365e17c0f40de4a"
 }
 ```

