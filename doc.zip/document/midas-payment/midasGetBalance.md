
### midasGetBalance

开通了虚拟支付的小游戏，可以通过本接口查看某个用户的游戏币余额

#### 正式环境
```
POST https://api.weixin.qq.com/cgi-bin/midas/getbalance?access_token=ACCESS_TOKEN
```
#### 沙箱环境
```
POST https://api.weixin.qq.com/cgi-bin/midas/sandbox/getbalance?access_token=ACCESS_TOKEN
```

#### 参数
| 参数 | 类型 | 默认值 | 是否必填 | 说明 |
| ---- | ---- | ------ | -------- | ---- |
| openid | string |  | 是 | 用户唯一标识符 |
| appid | string |  | 是 | 小程序 appId |
| offer_id | string |  | 是 | 米大师分配的offer_id |
| ts | number |  | 是 | UNIX 时间戳，单位是秒 |
| zone_id | string |  | 是 | 游戏服务器大区id,游戏不分大区则默认zoneId ="1",String类型。如过应用选择支持角色，则角色ID接在分区ID号后用"_"连接。 |
| pf | string |  | 是 | 平台 安卓：android |
| user_ip | string |  | 否 | 用户外网 IP |
| sig | string |  | 是 | 以上所有参数（含可选最多7个）+uri+米大师密钥，用 HMAC-SHA256签名，详见 [米大师支付签名算法](../../tutorial/open-ability/midas-signature.md) |
| access_token | string |  | 是 | 接口调用凭证 |
| mp_sig | string |  | 是 | 以上所有参数（含可选最多9个）+uri+session_key，用 HMAC-SHA256签名，详见 [米大师支付签名算法](../../tutorial/open-ability/midas-signature.md) |

#### 返回值
| 参数 | 类型 | 说明 |
| ---- | ---- | ---- |
| errcode | number | 错误码 |
| errmsg | number | 错误信息 |
| balance | number | 游戏币个数（包含赠送） |
| gen_balance | number | 赠送游戏币数量（赠送游戏币数量） |
| first_save | boolean | 是否满足历史首次充值 |
| save_amt | number | 累计充值金额的游戏币数量 |
| save_sum | number | 历史总游戏币金额 |
| cost_sum | number | 历史总消费游戏币金额 |
| present_sum | number | 历史累计收到赠送金额 |

**errcode 的合法值**

| 值 | 说明 |
| -- | ---- |
| 0 | 请求成功 |
| -1 | 系统繁忙，此时请开发者稍候再试 |
| 90009 | mp_sig签名错误 |
| 90010 | 用户未登录或登录态已过期 |
| 90011 | sig签名错误 |
| 90017 | 没有调用接口的权限 |
| 90018 | 参数错误 |

**first_save 的合法值**

| 值 | 说明 |
| -- | ---- |
| 1 | 满足 |
| 2 | 不满足 |

#### POST 数据格式：JSON

 ```
 {
     "openid":"odkx20ENSNa2w5y3g_qOkOvBNM1g",
     "appid":"wx1234567",
     "offer_id":"12345678",
     "ts":1507530737,
     "zone_id":"1",
     "pf":"android",
     "sig":"d1f0a41272f9b85618361323e1b19cd8cb0213f21b935aeaa39c160892031e97",
     "mp_sig":"ff4c5bb39dea1002a8f03be0438724e1a8bcea5ebce8f221f9b9fea3bcf3bf76"
 }
 ```

