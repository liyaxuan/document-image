
### midasCancelPay

开通了虚拟支付的小游戏，若扣除游戏币的订单号在有效时间内，可以通过本接口取消该笔扣除游戏币的订单

#### 正式环境
```
POST https://api.weixin.qq.com/cgi-bin/midas/cancelpay?access_token=ACCESS_TOKEN
```
#### 沙箱环境
```
POST https://api.weixin.qq.com/cgi-bin/midas/sandbox/cancelpay?access_token=ACCESS_TOKEN
```

#### 参数
| 参数 | 类型 | 默认值 | 是否必填 | 说明 |
| ---- | ---- | ------ | -------- | ---- |
| openid | string |  | 是 | 用户唯一标识符 |
| appid | string |  | 是 | 小程序 appId |
| offer_id | string |  | 是 | 米大师分配的offer_id |
| ts | number |  | 是 | UNIX 时间戳，单位是秒 |
| zone_id | string |  | 是 | 游戏服务器大区id,游戏不分大区则默认zoneId ="1",String类型。如过应用选择支持角色，则角色ID接在分区ID号后用"_"连接。 |
| pf | string |  | 是 | 平台 安卓：android |
| user_ip | string |  | 否 | 用户外网 IP |
| bill_no | string |  | 是 | 订单号，业务需要保证全局唯一；相同的订单号不会重复扣款。长度不超过63，只能是数字、大小写字母_-|*@ |
| pay_item | string |  | 否 | 道具名称 |
| sig | string |  | 是 | 以上所有参数（含可选最多9个）+uri+米大师密钥，用 HMAC-SHA256签名，详见 [米大师支付签名算法](../../tutorial/open-ability/midas-signature.md) |
| access_token | string |  | 是 | 接口调用凭证 |
| mp_sig | string |  | 是 | 以上所有参数（含可选最多11个）+uri+session_key，用 HMAC-SHA256签名，详见 [米大师支付签名算法](../../tutorial/open-ability/midas-signature.md) |

#### 返回值
| 参数 | 类型 | 说明 |
| ---- | ---- | ---- |
| errcode | number | 错误码 |
| errmsg | number | 错误信息 |
| bill_no | string | 扣除游戏币的订单号 |

**errcode 的合法值**

| 值 | 说明 |
| -- | ---- |
| 0 | 请求成功 |
| -1 | 系统繁忙，此时请开发者稍候再试 |
| 90000 | 订单不存在 |
| 90009 | mp_sig签名错误 |
| 90010 | 用户未登录或登录态已过期 |
| 90011 | sig签名错误 |
| 90014 | 订单已支付确认完成，不允许当前操作 |
| 90015 | 订单已回退，不允许当前操作 |
| 90016 | 订单处理中 |
| 90017 | 没有调用接口的权限 |
| 90018 | 参数错误 |

#### POST 数据格式：JSON

 ```
 {
     "openid":"odkx20ENSNa2w5y3g_qOkOvBNM1g",
     "appid":"wx1234567",
     "offer_id":"12345678",
     "ts":1507530737,
     "zone_id":"1",
     "pf":"android",
     "bill_no":"BillNo_123",
     "sig":"8bd582a6b06e38a1346fc335ebcb11c8990241bbe23118eb3d22f0ef42870a6a",
     "mp_sig":"2651b0ee9cc7e7e1791de388d34c4d0357936e9ab7b8a9db9ba7b0537208f72b"
 }
 ```

