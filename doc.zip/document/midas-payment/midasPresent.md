
### midasPresent

开通了虚拟支付的小游戏，可以通过该接口赠送游戏币给某个用户。

#### 正式环境
```
POST https://api.weixin.qq.com/cgi-bin/midas/present?access_token=ACCESS_TOKEN
```
#### 沙箱环境
```
POST https://api.weixin.qq.com/cgi-bin/midas/sandbox/present?access_token=ACCESS_TOKEN
```

#### 参数
| 参数 | 类型 | 默认值 | 是否必填 | 说明 |
| ---- | ---- | ------ | -------- | ---- |
| openid | string |  | 是 | 用户唯一标识符 |
| appid | string |  | 是 | 小程序 appId |
| offer_id | string |  | 是 | 米大师分配的offer_id |
| ts | number |  | 是 | UNIX 时间戳，单位是秒 |
| zone_id | string |  | 是 | 游戏服务器大区id,游戏不分大区则默认zoneId ="1",String类型。如过应用选择支持角色，则角色ID接在分区ID号后用"_"连接。 |
| pf | string |  | 是 | 平台 安卓：android |
| user_ip | string |  | 否 | 用户外网 IP |
| bill_no | string |  | 是 | 订单号，业务需要保证全局唯一；相同的订单号不会重复扣款。长度不超过63，只能是数字、大小写字母_-|*@ |
| present_counts | number |  | 是 | 赠送游戏币的个数，不能为0 |
| sig | string |  | 是 | 以上所有参数（含可选最多9个）+uri+米大师密钥，用 HMAC-SHA256签名，详见 [米大师支付签名算法](../../tutorial/open-ability/midas-signature.md) |
| access_token | string |  | 是 | 接口调用凭证 |
| mp_sig | string |  | 是 | 以上所有参数（含可选最多11个）+uri+session_key，用 HMAC-SHA256签名，详见 [米大师支付签名算法](../../tutorial/open-ability/midas-signature.md) |

#### 返回值
| 参数 | 类型 | 说明 |
| ---- | ---- | ---- |
| errcode | number | 错误码 |
| errmsg | number | 错误信息 |
| balance | number | 赠送后的余额 |
| bill_no | string | 赠送游戏币的订单号 |

**errcode 的合法值**

| 值 | 说明 |
| -- | ---- |
| 0 | 请求成功 |
| -1 | 系统繁忙，此时请开发者稍候再试 |
| 90009 | mp_sig签名错误 |
| 90010 | 用户未登录或登录态已过期 |
| 90011 | sig签名错误 |
| 90012 | 订单已存在 |
| 90017 | 没有调用接口的权限 |
| 90018 | 参数错误 |

#### POST 数据格式：JSON

 ```
 {
     "openid":"odkx20ENSNa2w5y3g_qOkOvBNM1g",
     "appid":"wx1234567",
     "offer_id":"12345678",
     "ts":1507530737,
     "zone_id":"1",
     "pf":"android",
     "present_counts":233,
     "bill_no":"BillNo_123",
     "sig":"e53e5241bbb014b3a9fcc221d66fecab8734b53fe94d7a8c65180e175e29f443",
     "mp_sig":"39271a12d8d56b0395981a0990a9e75ae239c54f419cb6235399fe70acf8ccfb"
 }
 ```

