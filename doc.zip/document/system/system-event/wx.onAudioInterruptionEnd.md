### wx.onAudioInterruptionEnd(function callback)

监听音频中断结束，在收到 onAudioInterruptionBegin 事件之后，小程序内所有音频会暂停，收到此事件之后才可再次播放成功

#### 参数

#####  callback

监听事件的回调函数

