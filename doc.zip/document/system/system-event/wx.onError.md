### wx.onError(function callback)

监听全局错误事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| message  | string | 错误 |   |
| stack  | string | 错误调用堆栈 |   |

