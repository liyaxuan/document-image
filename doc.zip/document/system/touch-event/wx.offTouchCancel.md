### wx.offTouchCancel(function callback)

取消监听触点失效事件

#### 参数

#####  callback

取消监听事件的回调函数

