### wx.onTouchCancel(function callback)

监听触点失效事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| touches  | Array.&lt;[Touch](Touch.md)&gt; | 当前所有触摸点的列表 |   |
| changedTouches  | Array.&lt;[Touch](Touch.md)&gt; | 触发此次事件的触摸点列表 |   |
| timeStamp  | number | 事件触发时的时间戳 |   |

