### wx.offTouchStart(function callback)

取消监听开始触摸事件

#### 参数

#####  callback

取消监听事件的回调函数

