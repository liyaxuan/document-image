### LaunchOption wx.getLaunchOptionsSync()

返回小程序启动参数

#### 返回值

##### LaunchOption

启动参数

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| scene  | number | 场景值 |   |
| query  | Object | 启动参数 |   |
| isSticky  | boolean | 当前小游戏是否被显示在聊天顶部 |   |
| shareTicket  | string | shareTicket |   |

