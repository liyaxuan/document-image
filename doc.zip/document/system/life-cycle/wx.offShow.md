### wx.offShow(function callback)

取消监听小游戏回到前台的事件

#### 参数

#####  callback

取消监听事件的回调函数

