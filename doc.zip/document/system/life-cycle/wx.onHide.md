### wx.onHide(function callback)

监听小游戏隐藏到后台事件。锁屏、按 HOME 键退到桌面、显示在聊天顶部等操作会触发此事件。

#### 参数

#####  callback

监听事件的回调函数

