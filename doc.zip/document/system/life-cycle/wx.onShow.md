### wx.onShow(function callback)

监听小游戏回到前台的事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| scene  | string | 场景值 |   |
| query  | Object | 查询参数 |   |
| shareTicket  | string | shareTicket |   |

