### Image wx.createImage()

创建一个图片对象

#### 返回值

##### [Image](Image.md)

图片对象

