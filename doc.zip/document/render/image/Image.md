### Image

图片对象

#### 属性

##### string src

图片的 URL

##### number width

图片的真实宽度

##### number height

图片的真实高度

##### function onload

图片加载完成后触发的回调函数

#### 方法

##### [Image wx.createImage()](wx.createImage.md)

创建一个图片对象

