### string wx.loadFont(string path)

加载自定义字体文件

#### 参数

##### string path

字体文件路径。可以是代码包文件路径，也可以是 wxfile:// 协议的本地文件路径。

#### 返回值

##### string

如果加载字体成功，则返回字体 family 值，否则返回 null。

