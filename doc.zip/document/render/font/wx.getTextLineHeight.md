### number wx.getTextLineHeight(Object object)

获取一行文本的行高

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| fontStyle | string | normal | 否 | 字体样式 |   |
| fontWeight | string | normal | 否 | 字重 |   |
| fontSize | number | 16 | 否 | 字号 |   |
| fontFamily | string |  | 是 | 字体名称 |   |
| text | string |  | 是 | 文本的内容 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

**object.fontStyle 的合法值**

| 值 | 说明 |
| -- | ---- |
| normal | 正常 |
| italic | 斜体 |

**object.fontWeight 的合法值**

| 值 | 说明 |
| -- | ---- |
| normal | 正常 |
| bold | 粗体 |

