### RenderingContext

通过 Canvas.getContext('2d') 接口可以获取 CanvasRenderingContext2D 对象。CanvasRenderingContext2D 实现了 [HTML Canvas 2D Context](https://www.w3.org/TR/2dcontext/) 定义的大部分属性、方法。通过 Canvas.getContext('webgl') 接口可以获取 WebGLRenderingContext 对象。
WebGLRenderingContext 实现了 [WebGL 1.0](https://www.khronos.org/registry/webgl/specs/latest/1.0/) 定义的所有属性、方法、常量。

#### 方法

##### [WebGLRenderingContext.wxBindCanvasTexture(number texture, Canvas canvas)](WebGLRenderingContext.wxBindCanvasTexture.md)

将一个 Canvas 对应的 Texture 绑定到 WebGL 上下文。

#### 2d 接口支持情况

iOS/Android 不支持的 2d 属性和接口

- globalCompositeOperation 不支持以下值： source-in source-out destination-atop lighter copy。如果使用，不会报错，但是将得到与预期不符的结果。
- isPointInPath

#### WebGL 接口支持情况

iOS/Android 不支持的 WebGL 接口

- pixelStorei 当第一个参数是 gl.UNPACK_COLORSPACE_CONVERSION_WEBGL 时
- compressedTexImage2D
- compressedTexSubImage2D

除此之外 Android 还不支持 WebGL 接口

- getExtension
- getSupportedExtensions

