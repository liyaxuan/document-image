### Canvas

画布对象

#### 属性

##### number width

画布的宽度

##### number height

画布的高度

#### 方法

##### [string Canvas.toTempFilePath(Object object)](Canvas.toTempFilePath.md)

将当前 Canvas 保存为一个临时文件，并生成相应的临时文件路径。

##### [RenderingContext Canvas.getContext(string contextType, Object contextAttributes)](Canvas.getContext.md)

获取画布对象的绘图上下文

##### [string Canvas.toDataURL()](Canvas.toDataURL.md)

把画布上的绘制内容以一个 data URI 的格式返回

##### [RenderingContext Canvas.getContext(string contextType, Object contextAttributes)](Canvas.getContext.md)

获取画布对象的绘图上下文

##### [string Canvas.toDataURL()](Canvas.toDataURL.md)

把画布上的绘制内容以一个 data URI 的格式返回

##### [WebGLRenderingContext.wxBindCanvasTexture(number texture, Canvas canvas)](WebGLRenderingContext.wxBindCanvasTexture.md)

将一个 Canvas 对应的 Texture 绑定到 WebGL 上下文。

##### [Canvas wx.getSharedCanvas()](wx.getSharedCanvas.md)

只有开放数据域能调用，获取主域和开放数据域共享的 sharedCanvas

