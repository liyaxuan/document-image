### WebGLRenderingContext.wxBindCanvasTexture(number texture, Canvas canvas)

将一个 Canvas 对应的 Texture 绑定到 WebGL 上下文。

#### 参数

##### number texture

WebGL 的纹理类型枚举值

##### [Canvas](Canvas.md) canvas

需要绑定为 Texture 的 Canvas

#### 示例代码

使用 wxBindCanvasTexture

```javascript
gl.wxBindCanvasTexture(gl.TEXTURE_2D, canvas)
```
等同于

```javascript
const texture = gl.createTexture()
gl.bindTexture(gl.TEXTURE_2D, texture)
......
gl.texImage2D(target, level, internalformat, format, type, canvas)
```

