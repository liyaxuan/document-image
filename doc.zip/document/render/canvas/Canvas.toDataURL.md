### string Canvas.toDataURL()

把画布上的绘制内容以一个 data URI 的格式返回

#### 返回值

##### string

data URI 格式的字符串

