### Canvas wx.createCanvas()

创建一个画布对象。首次调用创建的是显示在屏幕上的画布，之后调用创建的都是离屏画布。

#### 返回值

##### [Canvas](Canvas.md)

画布对象

