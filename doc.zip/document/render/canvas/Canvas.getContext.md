### RenderingContext Canvas.getContext(string contextType, Object contextAttributes)

获取画布对象的绘图上下文

#### 参数

##### string contextType

上下文类型

**contextType 的合法值**

| 值 | 说明 |
| -- | ---- |
| 2d | 2d 绘图上下文 |
| webgl | webgl 绘图上下文 |

##### Object contextAttributes

webgl 上下文属性，仅当 contextType 为 webgl 时有效

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| antialias | boolean | false | 否 | 表示是否抗锯齿 |   |
| preserveDrawingBuffer | boolean | false | 否 | 表示是否绘图完成后是否保留绘图缓冲区 |   |
| antialiasSamples | number | 2 | 否 | 抗锯齿样本数。最小值为 2，最大不超过系统限制数量，仅 iOS 支持 |   |

#### 返回值

##### [RenderingContext](RenderingContext.md)

绘图上下文

