### number requestAnimationFrame(function callback)

在下次进行重绘时执行。

#### 参数

##### function callback

执行的 callback

#### 返回值

##### number

请求 ID

