### cancelAnimationFrame(number requestID)

取消一个先前通过调用 requestAnimationFrame 方法添加到计划中的动画帧请求

#### 参数

##### number requestID

