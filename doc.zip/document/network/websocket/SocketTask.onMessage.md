### SocketTask.onMessage(function callback)

监听WebSocket 接受到服务器的消息事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| data  | string/ArrayBuffer | 服务器返回的消息 |   |

