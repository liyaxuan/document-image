### SocketTask wx.connectSocket(Object object)

创建一个 WebSocket 连接。最多同时存在 5 个 WebSocket 连接。

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| url | string |  | 是 | 开发者服务器接口地址，必须是 wss 协议，且域名必须是后台配置的合法域名 |   |
| header | Object |  | 是 | HTTP Header，Header 中不能设置 Referer |   |
| method | string | GET | 否 | 有效值：OPTIONS，GET，HEAD，POST，PUT，DELETE，TRACE，CONNECT |   |
| protocols | Array.&lt;string&gt; |  | 是 | 子协议数组 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

