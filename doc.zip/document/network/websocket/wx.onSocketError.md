### wx.onSocketError(function callback)

监听WebSocket 错误事件

#### 参数

#####  callback

监听事件的回调函数

