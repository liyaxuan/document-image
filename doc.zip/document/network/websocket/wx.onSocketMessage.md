### wx.onSocketMessage(function callback)

监听WebSocket 接受到服务器的消息事件

#### 参数

#####  callback

监听事件的回调函数

