### SocketTask

WebSocket 任务，可通过 wx.connectSocket() 接口创建返回

#### 方法

##### [SocketTask.send(Object object)](SocketTask.send.md)

通过 WebSocket 连接发送数据

##### [SocketTask.close(Object object)](SocketTask.close.md)

关闭 WebSocket 连接

##### [SocketTask.onOpen(function callback)](SocketTask.onOpen.md)

监听WebSocket 连接打开事件

##### [SocketTask.onClose(function callback)](SocketTask.onClose.md)

监听WebSocket 连接关闭事件

##### [SocketTask.onError(function callback)](SocketTask.onError.md)

监听WebSocket 错误事件

##### [SocketTask.onMessage(function callback)](SocketTask.onMessage.md)

监听WebSocket 接受到服务器的消息事件

##### [SocketTask.send(Object object)](SocketTask.send.md)

通过 WebSocket 连接发送数据

##### [SocketTask.close(Object object)](SocketTask.close.md)

关闭 WebSocket 连接

