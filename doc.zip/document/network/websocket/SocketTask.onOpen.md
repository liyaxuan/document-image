### SocketTask.onOpen(function callback)

监听WebSocket 连接打开事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| header  | object | 连接成功的 HTTP 响应 Header | 2.0.0 |

