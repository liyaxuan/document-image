### SocketTask.onClose(function callback)

监听WebSocket 连接关闭事件

#### 参数

#####  callback

监听事件的回调函数

