### DownloadTask

一个可以监听下载进度变化事件，以及取消下载任务的对象

#### 方法

##### [DownloadTask.abort()](DownloadTask.abort.md)

中断下载任务

##### [DownloadTask.onProgressUpdate(function callback)](DownloadTask.onProgressUpdate.md)

监听下载进度变化事件

##### [DownloadTask.abort()](DownloadTask.abort.md)

中断下载任务

