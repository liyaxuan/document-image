### DownloadTask wx.downloadFile(Object object)

下载文件资源到本地，客户端直接发起一个 HTTP GET 请求，返回文件的本地文件路径。

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| url | string |  | 是 | 下载资源的 url |   |
| header | Object |  | 是 | HTTP 请求的 Header，Header 中不能设置 Referer |   |
| filePath | string |  | 是 | 指定文件下载后存储的路径 | 1.8.0 |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

#### success 回调函数

##### 参数

###### Object res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| tempFilePath  | string | 临时文件路径。如果没传入 filePath 指定文件存储路径，则下载后的文件会存储到一个临时文件 |   |
| statusCode  | number | 开发者服务器返回的 HTTP 状态码 |   |

