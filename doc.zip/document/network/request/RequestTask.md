### RequestTask

网络请求任务对象

#### 方法

##### [RequestTask.abort()](RequestTask.abort.md)

中断请求任务

##### [RequestTask.abort()](RequestTask.abort.md)

中断请求任务

