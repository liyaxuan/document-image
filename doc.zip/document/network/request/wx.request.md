### RequestTask wx.request(Object object)

发起网络请求。

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| url | string |  | 是 | 开发者服务器接口地址 |   |
| data | string/object |  | 否 | 请求的参数 |   |
| header | Object |  | 否 | 设置请求的 header，header 中不能设置 Referer |   |
| method | string | GET | 否 | HTTP 请求方法 |   |
| dataType | string | json | 否 | 返回的数据格式 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

**object.method 的合法值**

| 值 | 说明 |
| -- | ---- |
| GET | HTTP 请求GET |
| HEAD | HTTP 请求 HEAD |
| POST | HTTP 请求 POST |
| PUT | HTTP 请求 PUT |
| DELETE | HTTP 请求 DELETE |
| TRACE | HTTP 请求 TRACE |
| CONNECT | HTTP 请求 CONNECT |

**object.dataType 的合法值**

| 值 | 说明 |
| -- | ---- |
| json | 返回的数据为 JSON，返回后会对返回的数据进行一次 JSON.parse |
| arraybuffer | 返回的数据为 ArrayBuffer |

#### success 回调函数

##### 参数

###### Object res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| data  | string/Object/Arraybuffer | 开发者服务器返回的数据 |   |
| statusCode  | number | 开发者服务器返回的 HTTP 状态码 |   |
| header  | Object | 开发者服务器返回的 HTTP Response Header | 1.2.0 |

