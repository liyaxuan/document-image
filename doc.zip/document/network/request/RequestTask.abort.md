### RequestTask.abort()

> 基础库 1.4.0 开始支持，低版本需做兼容处理

中断请求任务

