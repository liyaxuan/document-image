### UploadTask

一个可以监听上传进度变化事件，以及取消上传任务的对象

#### 方法

##### [UploadTask.abort()](UploadTask.abort.md)

中断上传任务

##### [UploadTask.onProgressUpdate(function callback)](UploadTask.onProgressUpdate.md)

监听上传进度变化事件

##### [UploadTask.abort()](UploadTask.abort.md)

中断上传任务

