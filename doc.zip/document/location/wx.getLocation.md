### wx.getLocation(Object object)

获取当前的地理位置、速度。当用户离开小程序后，此接口无法调用；当用户点击“显示在聊天顶部”时，此接口可继续调用。

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| type | string | wgs84 | 否 | wgs84 返回 gps 坐标，gcj02 返回可用于 wx.openLocation 的坐标 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

#### success 回调函数

##### 参数

###### Object res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| latitude  | number | 纬度，范围为 -90~90，负数表示南纬 |   |
| longitude  | number | 经度，范围为 -180~180，负数表示西经 |   |
| speed  | number | 速度，单位 m/s |   |
| accuracy  | number | 位置的精确度 |   |
| altitude  | number | 高度，单位 m |   |
| verticalAccuracy  | number | 垂直精度，单位 m（Android 无法获取，返回 0） |   |
| horizontalAccuracy  | number | 水平精度，单位 m |   |

