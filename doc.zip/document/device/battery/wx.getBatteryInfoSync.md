### string wx.getBatteryInfoSync()

wx.getBatteryInfo 的同步版本

#### 返回值

##### string

设备电量，范围 1 - 100

