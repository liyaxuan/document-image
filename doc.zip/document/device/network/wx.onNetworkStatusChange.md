### wx.onNetworkStatusChange(function callback)

> 基础库 1.1.0 开始支持，低版本需做兼容处理

监听网络状态变化事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| isConnected  | boolean | 当前是否有网络链接 |   |
| networkType  | string | 网络类型 |   |

**networkType 的合法值**

| 值 | 说明 |
| -- | ---- |
| wifi | wifi 网络 |
| 2g | 2g 网络 |
| 3g | 3g 网络 |
| 4g | 4g 网络 |
| unknown | Android 下不常见的网络类型 |
| none | 无网络 |

