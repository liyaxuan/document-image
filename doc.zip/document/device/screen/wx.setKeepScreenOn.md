### wx.setKeepScreenOn(Object object)

> 基础库 1.4.0 开始支持，低版本需做兼容处理

设置是否保持常亮状态。仅在当前小程序生效，离开小程序后设置失效。

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| keepScreenOn | boolean |  | 是 | keepScreenOn |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

