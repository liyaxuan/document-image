### wx.onCompassChange(function callback)

监听罗盘数据，频率：5 次/秒，接口调用后会自动开始监听，可使用 wx.stopCompass 停止监听。

#### 参数

##### function callback

监听罗盘数据的回调函数

#### callback 回调函数

##### 参数

###### Object object

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| direction  | number | 面对的方向度数 |   |

