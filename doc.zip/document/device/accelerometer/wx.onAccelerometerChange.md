### wx.onAccelerometerChange(function callback)

监听加速度数据，频率：5次/秒，接口调用后会自动开始监听，可使用 wx.stopAccelerometer 停止监听。

#### 参数

##### function callback

监听加速度数据的回调函数

#### callback 回调函数

##### 参数

###### Object res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| x  | number | x 轴 |   |
| y  | number | y 轴 |   |
| z  | number | z 轴 |   |

