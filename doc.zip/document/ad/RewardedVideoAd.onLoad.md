### RewardedVideoAd.onLoad(function callback)

监听激励视频广告加载事件

#### 参数

#####  callback

监听事件的回调函数

