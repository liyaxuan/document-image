### RewardedVideoAd

激励视频广告组件。激励视频广告组件是一个原生组件，并且是一个全局单例。层级比上屏 Canvas 高，会覆盖在上屏 Canvas 上。激励视频 广告组件默认是隐藏的，需要调用 RewardedVideoAd.show() 将其显示。

#### 属性

##### string adUnitId

广告单元 id

#### 方法

##### [Promise RewardedVideoAd.load()](RewardedVideoAd.load.md)

隐藏激励视频广告

##### [Promise RewardedVideoAd.show()](RewardedVideoAd.show.md)

显示激励视频广告。激励视频广告将从屏幕下方推入。

##### [RewardedVideoAd.onLoad(function callback)](RewardedVideoAd.onLoad.md)

监听激励视频广告加载事件

##### [RewardedVideoAd.offLoad(function callback)](RewardedVideoAd.offLoad.md)

取消监听激励视频广告加载事件

##### [RewardedVideoAd.onError(function callback)](RewardedVideoAd.onError.md)

监听激励视频错误事件

##### [RewardedVideoAd.offError(function callback)](RewardedVideoAd.offError.md)

取消监听激励视频错误事件

##### [RewardedVideoAd.onClose(function callback)](RewardedVideoAd.onClose.md)

监听用户点击 `关闭广告` 按钮的事件

##### [RewardedVideoAd.offClose(function callback)](RewardedVideoAd.offClose.md)

取消监听用户点击 `关闭广告` 按钮的事件

##### [Promise RewardedVideoAd.load()](RewardedVideoAd.load.md)

隐藏激励视频广告

##### [Promise RewardedVideoAd.show()](RewardedVideoAd.show.md)

显示激励视频广告。激励视频广告将从屏幕下方推入。

