### Promise BannerAd.show()

显示 banner 广告。

#### 返回值

##### Promise

banner 广告显示操作的结果

