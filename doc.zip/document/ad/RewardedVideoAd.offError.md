### RewardedVideoAd.offError(function callback)

取消监听激励视频错误事件

#### 参数

#####  callback

取消监听事件的回调函数

