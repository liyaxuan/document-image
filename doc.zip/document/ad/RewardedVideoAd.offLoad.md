### RewardedVideoAd.offLoad(function callback)

取消监听激励视频广告加载事件

#### 参数

#####  callback

取消监听事件的回调函数

