### Promise RewardedVideoAd.load()

隐藏激励视频广告

#### 返回值

##### Promise

激励视频广告加载数据的结果

