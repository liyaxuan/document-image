### RewardedVideoAd.onClose(function callback)

监听用户点击 `关闭广告` 按钮的事件

#### 参数

#####  callback

监听事件的回调函数

