### BannerAd.hide()

隐藏 banner 广告

