### RewardedVideoAd.offClose(function callback)

取消监听用户点击 `关闭广告` 按钮的事件

#### 参数

#####  callback

取消监听事件的回调函数

