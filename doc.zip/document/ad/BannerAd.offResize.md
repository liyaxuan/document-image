### BannerAd.offResize(function callback)

取消监听隐藏 banner 广告

#### 参数

#####  callback

取消监听事件的回调函数

