### BannerAd.destroy()

销毁 banner 广告

