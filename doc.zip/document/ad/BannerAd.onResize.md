### BannerAd.onResize(function callback)

监听隐藏 banner 广告

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| width  | number | 缩放后的宽度 |   |
| height  | number | 缩放后的高度 |   |

