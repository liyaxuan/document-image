### Promise RewardedVideoAd.show()

显示激励视频广告。激励视频广告将从屏幕下方推入。

#### 返回值

##### Promise

激励视频广告显示操作的结果

