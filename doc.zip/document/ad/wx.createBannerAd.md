### BannerAd wx.createBannerAd(Object object)

> 基础库 2.0.4 开始支持，低版本需做兼容处理

创建 banner 广告组件。请通过 [wx.getSystemInfoSync()](../system/system-info/wx.getSystemInfoSync.md) 返回对象的 SDKVersion 判断基础库版本号 &gt;= 2.0.4 后再使用该 API。同时，开发者工具上暂不支持调试该 API，请直接在真机上进行调试。

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| adUnitId | string |  | 是 | 广告单元 id |   |
| style | Object |  | 是 | banner 广告组件的样式 |   |

**object.style 的结构**

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| left | number |  | 是 | banner 广告组件的左上角横坐标 |   |
| top | number |  | 是 | banner 广告组件的左上角纵坐标 |   |
| width | number |  | 是 | banner 广告组件的宽度 |   |
| height | number |  | 是 | banner 广告组件的高度 |   |

#### 返回值

##### [BannerAd](BannerAd.md)

banner 广告组件

#### 注意

小游戏广告能力目前暂时以邀请制开放申请，请留意后续通知

