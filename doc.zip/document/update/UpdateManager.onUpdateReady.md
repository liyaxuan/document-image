### UpdateManager.onUpdateReady(function callback)

监听更新包下载成功回调

#### 参数

#####  callback

监听事件的回调函数

