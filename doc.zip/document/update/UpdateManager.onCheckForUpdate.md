### UpdateManager.onCheckForUpdate(function callback)

监听检查更新结果回调

#### 参数

#####  callback

监听事件的回调函数

