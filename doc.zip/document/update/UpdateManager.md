### UpdateManager

UpdateManager 实例，用来管理更新，可通过 [wx.getUpdateManager](wx.getUpdateManager.md) 接口获取实例。

#### 方法

##### [UpdateManager.applyUpdate()](UpdateManager.applyUpdate.md)

应用更新包并重启

##### [UpdateManager.onCheckForUpdate(function callback)](UpdateManager.onCheckForUpdate.md)

监听检查更新结果回调

##### [UpdateManager.onUpdateReady(function callback)](UpdateManager.onUpdateReady.md)

监听更新包下载成功回调

##### [UpdateManager.onUpdateFailed(function callback)](UpdateManager.onUpdateFailed.md)

监听更新包下载失败回调

##### [UpdateManager.applyUpdate()](UpdateManager.applyUpdate.md)

应用更新包并重启

##### [UpdateManager wx.getUpdateManager()](wx.getUpdateManager.md)

