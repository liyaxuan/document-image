### UpdateManager.applyUpdate()

应用更新包并重启

