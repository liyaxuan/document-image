### UpdateManager.onUpdateFailed(function callback)

监听更新包下载失败回调

#### 参数

#####  callback

监听事件的回调函数

