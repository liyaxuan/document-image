### UpdateManager wx.getUpdateManager()

#### 返回值

##### [UpdateManager](UpdateManager.md)

更新管理对象

