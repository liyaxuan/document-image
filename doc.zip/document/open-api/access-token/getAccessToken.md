
### getAccessToken

获取小程序 access_token 。access_token 介绍详见 https://mp.weixin.qq.com/wiki?t=resource/res_main&amp;id=mp1421140183

#### 请求地址
```
GET https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET
```

#### 参数
| 参数 | 类型 | 默认值 | 是否必填 | 说明 |
| ---- | ---- | ------ | -------- | ---- |
| grant_type | string |  | 是 | 填写 client_credential |
| appid | string |  | 是 | 小程序 appId |
| secret | string |  | 是 | 小程序 appSecret |

#### 返回值
| 参数 | 类型 | 说明 |
| ---- | ---- | ---- |
| access_token | string | 获取到的凭证 |
| errcode | number | 错误码 |
| errMsg | string | 错误信息 |

**errcode 的合法值**

| 值 | 说明 |
| -- | ---- |
| -1 | 系统繁忙，此时请开发者稍候再试 |
| 0 | 请求成功 |
| 40001 | AppSecret错误或者AppSecret不属于这个小程序，请开发者确认AppSecret的正确性 |
| 40002 | 请确保grant_type字段值为client_credential |
| 40164 | 调用接口的IP地址不在白名单中，请在接口IP白名单中进行设置 |

