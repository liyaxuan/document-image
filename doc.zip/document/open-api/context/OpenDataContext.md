### OpenDataContext

开放数据域对象

#### 属性

##### [Canvas](../../render/canvas/Canvas.md) canvas

开放数据域和主域共享的 sharedCanvas

#### 方法

##### [OpenDataContext.postMessage(Object message)](OpenDataContext.postMessage.md)

向开放数据域发送消息

##### [OpenDataContext.postMessage(Object message)](OpenDataContext.postMessage.md)

向开放数据域发送消息

##### [OpenDataContext wx.getOpenDataContext()](wx.getOpenDataContext.md)

获取开放数据域

