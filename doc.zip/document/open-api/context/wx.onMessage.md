### wx.onMessage(function callback)

监听主域发送的消息

#### 参数

##### function callback

监听事件的回调函数

#### callback 回调函数

##### 参数

###### Object data

主域发送的消息

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |

