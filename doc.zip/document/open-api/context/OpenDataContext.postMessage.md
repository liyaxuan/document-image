### OpenDataContext.postMessage(Object message)

向开放数据域发送消息

#### 参数

##### Object message

要发送的消息，message 中及嵌套对象中 key 的 value 只能是 primitive value。即 number、string、boolean、null、undefined。

