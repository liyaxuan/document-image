### OpenDataContext wx.getOpenDataContext()

> 基础库 1.9.92 开始支持，低版本需做兼容处理

获取开放数据域

#### 返回值

##### [OpenDataContext](OpenDataContext.md)

