### openCustomerServiceConversation(Object object)

> 基础库 2.0.3 开始支持，低版本需做兼容处理

进入客服会话，要求在用户发生过至少一次 touch 事件后才能调用。后台接入方式与小程序一致，详见 [客服消息接入](https://developers.weixin.qq.com/miniprogram/dev/api/custommsg/callback_help.html)

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| sessionFrom | string | '' | 否 | 会话来源 |   |
| showMessageCard | boolean | false | 否 | 是否显示会话内消息卡片，设置此参数为 true，用户进入客服会话之后会收到一个消息卡片，通过以下三个参数设置卡片的内容 |   |
| sendMessageTitle | string | '' | 否 | 会话内消息卡片标题 |   |
| sendMessagePath | string | '' | 否 | 会话内消息卡片路径 |   |
| sendMessageImg | string | '' | 否 | 会话内消息卡片图片路径 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

