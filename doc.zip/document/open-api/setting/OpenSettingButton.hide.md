### OpenSettingButton.hide()

隐藏打开设置页面的按钮

