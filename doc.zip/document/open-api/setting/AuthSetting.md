### AuthSetting

#### 属性

##### boolean scope.userInfo

用户信息，对应接口 wx.getUserInfo

##### boolean scope.userLocation

地理位置，对应接口 wx.getLocation wx.chooseLocation

##### boolean scope.address

通讯地址，对应接口 wx.chooseAddress

##### boolean scope.invoiceTitle

发票抬头，对应接口 wx.chooseInvoiceTitle

##### boolean scope.werun

微信运动步数，对应接口 wx.getWeRunData

##### boolean scope.record

录音功能，对应接口 wx.startRecord

##### boolean scope.writePhotosAlbum

保存到相册 wx.saveImageToPhotosAlbum, wx.saveVideoToPhotosAlbum

##### boolean scope.camera

摄像头

