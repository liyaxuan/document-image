### OpenSettingButton wx.createOpenSettingButton(Object object)

> 基础库 2.0.7 开始支持，低版本需做兼容处理

创建打开设置页面的按钮

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| type | string |  | 是 | 按钮的类型 |   |
| text | string |  | 是 | 按钮上的文本，仅当 type 为 `text` 时有效 |   |
| image | string |  | 是 | 按钮的背景图片，仅当 type 为 `image` 时有效 |   |
| style | Object |  | 是 | 按钮的样式 |   |

**object.type 的合法值**

| 值 | 说明 |
| -- | ---- |
| text | 可以设置背景色和文本的按钮 |
| image | 只能设置背景贴图的按钮，背景贴图会直接拉伸到按钮的宽高 |

**object.style 的结构**

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| left | number |  | 是 | 左上角横坐标 |   |
| top | number |  | 是 | 左上角纵坐标 |   |
| width | number |  | 是 | 宽度 |   |
| height | number |  | 是 | 高度 |   |
| backgroundColor | string |  | 是 | 背景颜色 |   |
| borderColor | string |  | 是 | 边框颜色 |   |
| borderWidth | number |  | 是 | 边框宽度 |   |
| borderRadius | number |  | 是 | 边框圆角 |   |
| textAlign | string |  | 是 | 文本的水平居中方式 |   |
| fontSize | number |  | 是 | 字号 |   |
| lineHeight | number |  | 是 | 文本的行高 |   |

**object.style.textAlign 的合法值**

| 值 | 说明 |
| -- | ---- |
| left | 居左 |
| center | 居中 |
| right | 居右 |

#### 返回值

##### [OpenSettingButton](OpenSettingButton.md)

#### 示例代码

```javascript
let button = wx.createOpenSettingButton({
    type: 'text',
    text: '打开设置页面',
    style: {
        left: 10,
        top: 76,
        width: 200,
        height: 40,
        lineHeight: 40,
        backgroundColor: '#ff0000',
        color: '#ffffff',
        textAlign: 'center',
        fontSize: 16,
        borderRadius: 4
    }
})
```

