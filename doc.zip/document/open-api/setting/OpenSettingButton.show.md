### OpenSettingButton.show()

显示打开设置页面的按钮

