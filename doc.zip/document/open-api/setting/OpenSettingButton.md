### OpenSettingButton

打开设置页面的按钮

#### 属性

##### string text

按钮上的文本，仅当 type 为 `text` 时有效

##### string image

按钮的背景图片，仅当 type 为 `image` 时有效

##### [Style]() style

按钮的样式

#### 方法

##### [OpenSettingButton.show()](OpenSettingButton.show.md)

显示打开设置页面的按钮

##### [OpenSettingButton.hide()](OpenSettingButton.hide.md)

隐藏打开设置页面的按钮

##### [OpenSettingButton.destroy()](OpenSettingButton.destroy.md)

销毁打开设置页面的按钮

##### [OpenSettingButton.onTap(function callback)](OpenSettingButton.onTap.md)

监听打开设置页面的按钮点击事件

##### [OpenSettingButton.offTap(function callback)](OpenSettingButton.offTap.md)

取消监听打开设置页面的按钮点击事件

##### [OpenSettingButton.show()](OpenSettingButton.show.md)

显示打开设置页面的按钮

##### [OpenSettingButton.hide()](OpenSettingButton.hide.md)

隐藏打开设置页面的按钮

##### [OpenSettingButton.destroy()](OpenSettingButton.destroy.md)

销毁打开设置页面的按钮

