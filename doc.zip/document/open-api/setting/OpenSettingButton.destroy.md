### OpenSettingButton.destroy()

销毁打开设置页面的按钮

