### wx.getWeRunData(Object object)

> 基础库 1.2.0 开始支持，低版本需做兼容处理

获取用户过去三十天微信运动步数，需要先调用 wx.login 接口。需要用户授权 scope.werun。

#### 参数

#####  object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

#### success 回调函数

##### 参数

###### Object res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| encryptedData  | string | 包括敏感数据在内的完整用户信息的加密数据，详细见[加密数据解密算法](../../../tutorial/open-ability/signature.md) |   |
| iv  | string | 加密算法的初始向量，详细见[加密数据解密算法](../../../tutorial/open-ability/signature.md) |   |

