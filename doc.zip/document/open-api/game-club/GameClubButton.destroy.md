### GameClubButton.destroy()

销毁游戏圈按钮

