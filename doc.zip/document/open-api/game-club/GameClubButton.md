### GameClubButton

游戏圈按钮

#### 属性

##### Object style

按钮的样式

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| left  | number | 左上角横坐标 |   |
| top  | number | 左上角纵坐标 |   |
| width  | number | 宽度 |   |
| height  | number | 高度 |   |

#### 方法

##### [GameClubButton.show()](GameClubButton.show.md)

显示游戏圈按钮

##### [GameClubButton.hide()](GameClubButton.hide.md)

隐藏游戏圈按钮

##### [GameClubButton.destroy()](GameClubButton.destroy.md)

销毁游戏圈按钮

##### [GameClubButton.show()](GameClubButton.show.md)

显示游戏圈按钮

##### [GameClubButton.hide()](GameClubButton.hide.md)

隐藏游戏圈按钮

##### [GameClubButton.destroy()](GameClubButton.destroy.md)

销毁游戏圈按钮

