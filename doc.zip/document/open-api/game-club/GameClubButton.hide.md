### GameClubButton.hide()

隐藏游戏圈按钮

