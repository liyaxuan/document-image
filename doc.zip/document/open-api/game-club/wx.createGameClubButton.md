### GameClubButton wx.createGameClubButton(Object object)

> 基础库 2.0.3 开始支持，低版本需做兼容处理

创建游戏圈按钮。游戏圈按钮被点击后会跳转到小游戏的游戏圈。更多关于游戏圈的信息见 [游戏圈使用指南](../../../tutorial/open-ability/game-club.md)

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| icon | string |  | 是 | 游戏圈按钮的图标 |   |
| style | Object |  | 是 | 按钮的样式 |   |

**object.icon 的合法值**

| 值 | 说明 |
| -- | ---- |
| green | 绿色的图标 |
| white | 白色的图标 |
| dark | 有黑色圆角背景的白色图标 |
| light | 有白色圆角背景的绿色图标 |

**object.style 的结构**

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| left | number |  | 是 | 左上角横坐标 |   |
| top | number |  | 是 | 左上角纵坐标 |   |
| width | number |  | 是 | 宽度 |   |
| height | number |  | 是 | 高度 |   |

#### 返回值

##### [GameClubButton](GameClubButton.md)

#### 示例代码

```javascript
let button = wx.createGameClubButton({
    icon: 'green',
    style: {
        left: 10,
        top: 76,
        width: 40,
        height: 40
    }
})
```

