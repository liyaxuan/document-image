### UserInfo

#### 属性

##### string language

显示 country province city 所用的语言

##### string nickName

用户昵称

##### string avatarUrl

用户头像图片 url。最后一个数值代表正方形头像大小（有0、46、64、96、132数值可选，0代表640*640正方形头像），用户没有头像时该项为空。若用户更换头像，原有头像 url 将失效。

**avatarUrl 的合法值**

| 值 | 说明 |
| -- | ---- |
| 0 | 640x640 的正方形头像 |
| 46 | 46x46 的正方形头像 |
| 64 | 64x64 的正方形头像 |
| 96 | 96x96 的正方形头像 |
| 132 | 132x132 的正方形头像 |

##### number gender

用户性别

**gender 的合法值**

| 值 | 说明 |
| -- | ---- |
| 0 | 未知 |
| 1 | 男性 |
| 2 | 女性 |

##### string country

用户所在国家

##### string province

用户所在省份

##### string city

用户所在城市

