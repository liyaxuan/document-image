### UserInfoButton.show()

显示用户信息按钮

