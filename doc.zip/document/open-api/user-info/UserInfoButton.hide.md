### UserInfoButton.hide()

隐藏用户信息按钮

