### UserInfoButton

用户信息按钮

#### 属性

##### string text

按钮上的文本，仅当 type 为 `text` 时有效

##### string image

按钮的背景图片，仅当 type 为 `image` 时有效

##### [Style]() style

按钮的样式

#### 方法

##### [UserInfoButton.show()](UserInfoButton.show.md)

显示用户信息按钮

##### [UserInfoButton.hide()](UserInfoButton.hide.md)

隐藏用户信息按钮

##### [UserInfoButton.destroy()](UserInfoButton.destroy.md)

销毁用户信息按钮

##### [UserInfoButton.onTap(function callback)](UserInfoButton.onTap.md)

监听用户信息按钮点击事件

##### [UserInfoButton.offTap(function callback)](UserInfoButton.offTap.md)

取消监听用户信息按钮点击事件

##### [UserInfoButton.show()](UserInfoButton.show.md)

显示用户信息按钮

##### [UserInfoButton.hide()](UserInfoButton.hide.md)

隐藏用户信息按钮

##### [UserInfoButton.destroy()](UserInfoButton.destroy.md)

销毁用户信息按钮

