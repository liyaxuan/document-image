### UserInfoButton.onTap(function callback)

监听用户信息按钮点击事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| userInfo  | [UserInfo](UserInfo.md) | 用户信息对象，不包含 openid 等敏感信息 |   |
| rawData  | string | 不包括敏感信息的原始数据字符串，用于计算签名 |   |
| signature  | string | 使用 sha1( rawData + sessionkey ) 得到字符串，用于校验用户信息，参考文档[signature](../../../tutorial/open-ability/http-signature.md) |   |
| encryptedData  | string | 包括敏感数据在内的完整用户信息的加密数据，详细见[加密数据解密算法](../../../tutorial/open-ability/signature.md) |   |
| iv  | string | 加密算法的初始向量，详细见[加密数据解密算法](../../../tutorial/open-ability/signature.md) |   |

