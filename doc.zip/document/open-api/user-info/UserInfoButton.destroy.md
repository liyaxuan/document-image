### UserInfoButton.destroy()

销毁用户信息按钮

