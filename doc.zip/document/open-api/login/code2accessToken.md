
### code2accessToken

登录凭证校验，开发者服务器使用 临时登录凭证code 获取 session_key 和 openid 等。

#### 请求地址
```
GET https://api.weixin.qq.com/sns/jscode2session?appid=APPID&secret=SECRET&js_code=JSCODE&grant_type=authorization_code
```

#### 参数
| 参数 | 类型 | 默认值 | 是否必填 | 说明 |
| ---- | ---- | ------ | -------- | ---- |
| appid | string |  | 是 | 小程序 appId |
| secret | string |  | 是 | 小程序 appSecret |
| js_code | string |  | 是 | 登录时获取的 cod |
| grant_type | string |  | 是 | 填写为 authorization_code |

#### 返回值
| 参数 | 类型 | 说明 |
| ---- | ---- | ---- |
| openid | string | 用户唯一标识 |
| session_key | string | 会话密钥 |
| uinionid | string | 用户在开放平台的唯一标识符，在满足 UnionID 下发条件的情况下会返回，具体参看 [UinionID 机制说明](https://mp.weixin.qq.com/debug/wxadoc/dev/api/uinionID.html)。 |
| errcode | number | 错误码 |
| errMsg | string | 错误信息 |

**errcode 的合法值**

| 值 | 说明 |
| -- | ---- |
| -1 | 系统繁忙，此时请开发者稍候再试 |
| 0 | 请求成功 |
| 40029 | code 无效 |

