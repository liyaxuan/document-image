
### setUserStorage

上报用户数据后台接口。小游戏可以通过本接口上报key-value数据到用户的CloudStorage。

#### 请求地址
```
POST https://api.weixin.qq.com/wxa/set_user_storage?access_token=ACCESS_TOKEN&signature=SIGNATURE&openid=OPENID&sig_method=SIG_METHOD
```

#### 参数
| 参数 | 类型 | 默认值 | 是否必填 | 说明 |
| ---- | ---- | ------ | -------- | ---- |
| access_token | string |  | 是 | 接口调用凭证 |
| openid | string |  | 是 | 用户唯一标识符 |
| appid | string |  | 是 | 小程序 appId |
| signature | string |  | 是 | 用户登录态签名，签名算法请参考[用户登录态签名算法](../../../tutorial/open-ability/http-signature.md) |
| sig_method | string |  | 是 | 用户登录态签名的哈希方法，如hmac_sha256等，请参考[用户登录态签名算法](../../../tutorial/open-ability/http-signature.md) |
| kv_list | Object |  | 是 | 要上报的数据 |

#### 返回值
| 参数 | 类型 | 说明 |
| ---- | ---- | ---- |
| errcode | number | 错误码 |
| errmsg | number | 错误信息 |

**errcode 的合法值**

| 值 | 说明 |
| -- | ---- |
| 0 | 请求成功 |
| -1 | 系统繁忙，此时请开发者稍候再试 |
| 87016 | 由于某个key-value长度超过限制而上报失败。 |
| 87017 | 由于用户存储的数据量超过限制而上报失败。 |
| 87018 | 由于用户存储的key-value对数量超过限制而上报失败。 |
| 87019 | 由于某个key长度超过限制而上报失败。 |

#### 示例代码

```javascript
curl - d '{ "kv_list":[{"key":"score","value":"100"},{"key":"gold","value":"3000"}] }'\'https://api.weixin.qq.com/wxa/set_user_storage?access_token=ACCESS_TOKEN&signature=SIGNATURE&openid=OPENID&sig_method=SIG_METHOD'
```

#### 托管数据的限制

如果在上报数据时触发这些限制，设置数据会失败并且会收到带错误码的返回包。

 1. 每个openid所标识的微信用户，在游戏当中的托管的数据不能超过128个key-value对。
 2. 上报的key-value列表当中每一项的key+value长度都不能超过1K(1024)字节。
 3. 上报的key-value列表当中每一个key长度都不能超过128字节。

