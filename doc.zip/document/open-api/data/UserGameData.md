### UserGameData

#### 属性

##### string avatarUrl

用户的微信头像 url

##### string nickname

用户的微信昵称

##### string openid

用户的 openid

##### Array.&lt;[KVData](KVData.md)&gt; KVDataList

用户的托管 KV 数据列表

