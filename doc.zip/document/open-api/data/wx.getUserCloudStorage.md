### wx.getUserCloudStorage(Object object)

> 基础库 1.9.92 开始支持，低版本需做兼容处理

获取当前用户托管数据当中对应 key 的数据。该接口只可在开放数据域下使用

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| keyList | Array.&lt;string&gt; |  | 是 | 要获取的 key 列表 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

#### success 回调函数

##### 参数

###### Object res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| KVDataList  | Array.&lt;[KVData](KVData.md)&gt; | 用户托管的 KV 数据列表 |   |

