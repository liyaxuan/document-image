### Canvas wx.getSharedCanvas()

只有开放数据域能调用，获取主域和开放数据域共享的 sharedCanvas

#### 返回值

##### [Canvas](../../render/canvas/Canvas.md)

画布对象

