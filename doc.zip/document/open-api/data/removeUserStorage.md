
### removeUserStorage

小游戏可以通过本接口删除已经上报到微信的key-value数据

#### 请求地址
```
POST https://api.weixin.qq.com/wxa/remove_user_storage?access_token=ACCESS_TOKEN&signature=SIGNATURE&openid=OPENID&sig_method=SIG_METHOD
```

#### 参数
| 参数 | 类型 | 默认值 | 是否必填 | 说明 |
| ---- | ---- | ------ | -------- | ---- |
| access_token | string |  | 是 | 接口调用凭证 |
| openid | string |  | 是 | 用户唯一标识符 |
| appid | string |  | 是 | 小程序 appId |
| signature | string |  | 是 | 用户登录态签名，签名算法请参考[用户登录态签名算法](../../../tutorial/open-ability/http-signature.md) |
| sig_method | string |  | 是 | 用户登录态签名的哈希方法，如hmac_sha256等，请参考[用户登录态签名算法](../../../tutorial/open-ability/http-signature.md) |
| key | string |  | 是 | 要删除的数据key列表 |

#### 返回值
| 参数 | 类型 | 说明 |
| ---- | ---- | ---- |
| errcode | number | 错误码 |
| errmsg | number | 错误信息 |

**errcode 的合法值**

| 值 | 说明 |
| -- | ---- |
| 0 | 请求成功 |
| -1 | 系统繁忙，此时请开发者稍候再试 |

#### 示例代码

```javascript
curl - d '{ "key":["gold", "score"] }'\'https://api.weixin.qq.com/wxa/remove_user_storage?access_token=ACCESS_TOKEN&signature=SIGNATURE&openid=OPENID&sig_method=SIG_METHOD'
```

