### wx.checkIsUserAdvisedToRest(Object object)

> 基础库 1.9.97 开始支持，低版本需做兼容处理

根据用户当天游戏时间判断用户是否需要休息

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| todayPlayedTime | number |  | 是 | 今天已经玩游戏的时间，单位：秒 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

#### success 回调函数

##### 参数

###### Object res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| result  | boolean | 是否建议用户休息 |   |

