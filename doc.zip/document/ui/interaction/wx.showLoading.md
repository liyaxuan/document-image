### wx.showLoading(Object object)

> 基础库 1.1.0 开始支持，低版本需做兼容处理

显示 loading 提示框, 需主动调用 wx.hideLoading 才能关闭提示框

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| title | string |  | 是 | 提示的内容 |   |
| mask | boolean | false | 否 | 是否显示透明蒙层 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

