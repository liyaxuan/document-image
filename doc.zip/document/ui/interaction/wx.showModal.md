### wx.showModal(Object object)

显示模态对话框

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| title | string |  | 是 | 提示的标题 |   |
| content | string |  | 是 | 提示的内容 |   |
| showCancel | boolean | true | 否 | 是否显示取消按钮 |   |
| cancelText | string |  | 是 | 取消按钮的文字，最多 4 个字符串 |   |
| cancelColor | string | #000000 | 否 | 取消按钮的文字颜色，必须是 16 进制格式的颜色字符串 |   |
| confirmText | string |  | 是 | 确认按钮的文字，最多 4 个字符串 |   |
| confirmColor | string | #3cc51f | 否 | 确认按钮的文字颜色，必须是 16 进制格式的颜色字符串 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

#### success 回调函数

##### 参数

###### Object res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| confirm  | boolean | 为 true 时，表示用户点击了确定按钮 |   |
| cancel  | boolean | 为 true 时，表示用户点击了取消（用于 Android 系统区分点击蒙层关闭还是点击取消按钮关闭） | 1.1.0 |

