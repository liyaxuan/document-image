### wx.onWindowResize(function callback)

监听窗口尺寸变化事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| windowWidth  | number | 变化后的窗口宽度，单位 px |   |
| windowHeight  | number | 变化后的窗口高度，单位 px |   |

