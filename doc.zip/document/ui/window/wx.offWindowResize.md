### wx.offWindowResize(function callback)

取消监听窗口尺寸变化事件

#### 参数

#####  callback

取消监听事件的回调函数

