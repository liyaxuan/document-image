### wx.offKeyboardConfirm(function callback)

取消监听用户点击键盘 Confirm 按钮时的事件

#### 参数

#####  callback

取消监听事件的回调函数

