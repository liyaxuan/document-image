### wx.onKeyboardInput(function callback)

监听键盘输入事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| value  | Object | 键盘输入的当前值 |   |

