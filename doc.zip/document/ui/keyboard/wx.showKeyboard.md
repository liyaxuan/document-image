### wx.showKeyboard(Object object)

显示键盘

#### 参数

##### Object object

| 属性 | 类型 | 默认值 | 是否必填 | 说明 | 支持版本 |
| ---- | ---- | ------ | -------- | ---- | -------- |
| defaultValue | string |  | 是 | 键盘输入框显示的默认值 |   |
| maxLength | number |  | 是 | 键盘中文本的最大长度 |   |
| multiple | boolean |  | 是 | 是否为多行输入 |   |
| confirmHold | boolean |  | 是 | 当点击完成时键盘是否收起 |   |
| confirmType | string |  | 是 | 键盘右下角 confirm 按钮的类型，只影响按钮的文本内容 |   |
| success | function |  | 否 | 接口调用成功的回调函数 |   |
| fail | function |  | 否 | 接口调用失败的回调函数 |   |
| complete | function |  | 否 | 接口调用结束的回调函数（调用成功、失败都会执行） |   |

**object.confirmType 的合法值**

| 值 | 说明 |
| -- | ---- |
| done | 完成 |
| next | 下一个 |
| search | 搜索 |
| go | 前往 |
| send | 发送 |

