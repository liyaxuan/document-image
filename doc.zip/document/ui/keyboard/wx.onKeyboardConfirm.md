### wx.onKeyboardConfirm(function callback)

监听用户点击键盘 Confirm 按钮时的事件

#### 参数

#####  callback

监听事件的回调函数

#### callback 回调函数

##### 参数

######  res

| 属性 | 类型 | 说明 | 支持版本 |
| ---- | ---- | ---- | -------- |
| value  | string | 键盘输入的当前值 |   |

