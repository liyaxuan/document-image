项目页卡主要有三大功能

## 显示当前项目细节

包括图标、AppID、第三方平台名（只有第三方平台的开发小程序才会显示）、目录信息、上次提交代码的时间以及代码包大小。

## 基础库版本切换

开发者可以在此选择任意基础库版本，用于开发和调试旧版本兼容问题。

![clientlib](../image/devtools2/clientlib.png)

### ES6 转 ES5

在 0.10.101000 以及之后版本的开发工具中，会默认使用 `babel` 将开发者 `ES6` 语法代码转换为三端都能很好支持的 `ES5` 的代码，帮助开发者解决环境不同所带来的开发问题。

需要注意的是：
- 为了提高代码质量，在开启 `ES6` 转换功能的情况下，默认启用 `javasctipt` 严格模式，请参考  ["use strict"]( https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Strict_mode)

### 压缩代码

开启此选项，开发工具在上传代码时候将会帮助开发者压缩 `javascript` 代码，减小代码包体积。

**Tips**

- 目前如果单个文件超过 500kb ，会引起工具内存的大量占用，所以超过 500kb 的文件将不会被压缩 [详情](https://developers.weixin.qq.com/blogdetail?action=get_post_info&lang=zh_CN&token=&docid=000e0696f084e0b0f21613f6a51804)

### 不校验请求域名及 TLS 版本

正式发布的小程序的网络请求是需要校验合法域名以及域名的 TLS 版本，可以在 mp 管理后台进行配置。
在开发过程中可以开启此选项，开发工具将不会校验安全域名，以及 TLS 版本，帮助在开发过程中更方便的完成调试工作。

![edit](../image/devtools2/righttools.png)

## 域名信息

将显示小程序的安全域名信息，合法域名可在 mp 管理后台进行设置。

![host](../image/devtools2/host.png)

